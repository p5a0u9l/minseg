/*
 * File: MinSeg_Controller_css_types.h
 *
 * Code generated for Simulink model 'MinSeg_Controller_css'.
 *
 * Model version                  : 1.102
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * TLC version                    : 8.7 (Aug  5 2014)
 * C/C++ source code generated on : Wed Mar 11 17:56:19 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MinSeg_Controller_css_types_h_
#define RTW_HEADER_MinSeg_Controller_css_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct Parameters_MinSeg_Controller_cs_ Parameters_MinSeg_Controller_cs;

/* Forward declaration for rtModel */
typedef struct tag_RTM_MinSeg_Controller_css RT_MODEL_MinSeg_Controller_css;

#endif                                 /* RTW_HEADER_MinSeg_Controller_css_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
