/*
 * File: MinSeg_Controller_css.c
 *
 * Code generated for Simulink model 'MinSeg_Controller_css'.
 *
 * Model version                  : 1.102
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * TLC version                    : 8.7 (Aug  5 2014)
 * C/C++ source code generated on : Wed Mar 11 17:56:19 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MinSeg_Controller_css.h"
#include "MinSeg_Controller_css_private.h"

/* Block signals (auto storage) */
BlockIO_MinSeg_Controller_css MinSeg_Controller_css_B;

/* Block states (auto storage) */
D_Work_MinSeg_Controller_css MinSeg_Controller_css_DWork;

/* Real-time model */
RT_MODEL_MinSeg_Controller_css MinSeg_Controller_css_M_;
RT_MODEL_MinSeg_Controller_css *const MinSeg_Controller_css_M =
  &MinSeg_Controller_css_M_;

/* Model output function */
void MinSeg_Controller_css_output(void)
{
  /* local block i/o variables */
  real_T rtb_Add_o;
  int32_T j;
  int32_T cff;
  real_T rtb_DiscreteFIRFilter;
  boolean_T Compare;
  int16_T i;
  real_T u0;

  /* Clock: '<Root>/Clock1' */
  rtb_Add_o = MinSeg_Controller_css_M->Timing.t[0];

  /* Switch: '<S16>/Switch' incorporates:
   *  Delay: '<Root>/Delay'
   *  Memory: '<S16>/IC=ic'
   */
  if (MinSeg_Controller_css_DWork.Delay_DSTATE) {
    MinSeg_Controller_css_B.Switch = rtb_Add_o;
  } else {
    MinSeg_Controller_css_B.Switch =
      MinSeg_Controller_css_DWork.ICic_PreviousInput;
  }

  /* End of Switch: '<S16>/Switch' */

  /* Sum: '<Root>/Add' */
  rtb_Add_o -= MinSeg_Controller_css_B.Switch;

  /* Outputs for Enabled SubSystem: '<Root>/Clear 13 ' incorporates:
   *  EnablePort: '<S1>/Enable'
   */
  /* Logic: '<S5>/AND' incorporates:
   *  Constant: '<S5>/Lower Limit'
   *  Constant: '<S5>/Upper Limit'
   *  RelationalOperator: '<S5>/Lower Test'
   *  RelationalOperator: '<S5>/Upper Test'
   *  S-Function (sfcn_Digital_Out): '<S1>/S-Function Builder'
   */
  if ((MinSeg_Controller_css_P.tstart < rtb_Add_o) && (rtb_Add_o <
       MinSeg_Controller_css_P.tstart + 0.1)) {
    if (!MinSeg_Controller_css_DWork.Clear13_MODE) {
      /* S-Function Block: <S1>/S-Function Builder */
      {
        real_T initVector[1] = { 0 };

        {
          int_T i1;
          for (i1=0; i1 < 1; i1++) {
            MinSeg_Controller_css_DWork.SFunctionBuilder_DSTATE = initVector[0];
          }
        }
      }

      MinSeg_Controller_css_DWork.Clear13_MODE = true;
    }

    /* DataTypeConversion: '<S1>/Data Type Conversion' incorporates:
     *  Constant: '<S1>/Constant'
     *  S-Function (sfcn_Digital_Out): '<S1>/S-Function Builder'
     */
    MinSeg_Controller_css_B.DataTypeConversion_e =
      (MinSeg_Controller_css_P.Constant_Value != 0.0);

    /* S-Function (sfcn_Digital_Out): '<S1>/S-Function Builder' */
    sfcn_Digital_Out_Outputs_wrapper
      (&MinSeg_Controller_css_B.DataTypeConversion_e,
       &MinSeg_Controller_css_DWork.SFunctionBuilder_DSTATE,
       &MinSeg_Controller_css_P.SFunctionBuilder_P1, 1);
  } else {
    if (MinSeg_Controller_css_DWork.Clear13_MODE) {
      MinSeg_Controller_css_DWork.Clear13_MODE = false;
    }
  }

  /* End of Logic: '<S5>/AND' */
  /* End of Outputs for SubSystem: '<Root>/Clear 13 ' */

  /* S-Function (sf_MPU6050_Driver_GxAyz): '<Root>/Gyro Driver SFunction' */
  sf_MPU6050_Driver_GxAyz_Outputs_wrapper
    ( &MinSeg_Controller_css_B.GyroDriverSFunction_o1,
     &MinSeg_Controller_css_B.GyroDriverSFunction_o2,
     &MinSeg_Controller_css_B.GyroDriverSFunction_o3,
     &MinSeg_Controller_css_DWork.GyroDriverSFunction_DSTATE);

  /* DataTypeConversion: '<Root>/Data Type  Conversion1' */
  MinSeg_Controller_css_B.DataTypeConversion1 =
    MinSeg_Controller_css_B.GyroDriverSFunction_o1;

  /* RelationalOperator: '<S2>/Compare' incorporates:
   *  Constant: '<S2>/Constant'
   */
  Compare = (rtb_Add_o > MinSeg_Controller_css_P.tstart);

  /* Outputs for Enabled SubSystem: '<Root>/Gyro Calibration' incorporates:
   *  EnablePort: '<S4>/Enable'
   */
  /* Logic: '<Root>/Logical Operator' */
  if (!Compare) {
    if (!MinSeg_Controller_css_DWork.GyroCalibration_MODE) {
      /* InitializeConditions for DiscreteFir: '<S4>/Discrete FIR Filter' */
      MinSeg_Controller_css_DWork.DiscreteFIRFilter_circBuf = 0L;
      for (i = 0; i < 99; i++) {
        MinSeg_Controller_css_DWork.DiscreteFIRFilter_states[i] =
          MinSeg_Controller_css_P.DiscreteFIRFilter_InitialStates;
      }

      /* End of InitializeConditions for DiscreteFir: '<S4>/Discrete FIR Filter' */
      MinSeg_Controller_css_DWork.GyroCalibration_MODE = true;
    }
  } else {
    if (MinSeg_Controller_css_DWork.GyroCalibration_MODE) {
      MinSeg_Controller_css_DWork.GyroCalibration_MODE = false;
    }
  }

  /* End of Logic: '<Root>/Logical Operator' */
  if (MinSeg_Controller_css_DWork.GyroCalibration_MODE) {
    /* DiscreteFir: '<S4>/Discrete FIR Filter' */
    rtb_DiscreteFIRFilter = MinSeg_Controller_css_B.DataTypeConversion1 *
      MinSeg_Controller_css_P.DiscreteFIRFilter_Coefficients[0];
    cff = 1L;
    for (j = MinSeg_Controller_css_DWork.DiscreteFIRFilter_circBuf; j < 99L; j++)
    {
      rtb_DiscreteFIRFilter +=
        MinSeg_Controller_css_DWork.DiscreteFIRFilter_states[j] *
        MinSeg_Controller_css_P.DiscreteFIRFilter_Coefficients[cff];
      cff++;
    }

    for (j = 0L; j < MinSeg_Controller_css_DWork.DiscreteFIRFilter_circBuf; j++)
    {
      rtb_DiscreteFIRFilter +=
        MinSeg_Controller_css_DWork.DiscreteFIRFilter_states[j] *
        MinSeg_Controller_css_P.DiscreteFIRFilter_Coefficients[cff];
      cff++;
    }

    /* End of DiscreteFir: '<S4>/Discrete FIR Filter' */

    /* Gain: '<S4>/Gain2' */
    MinSeg_Controller_css_B.Gain2 = MinSeg_Controller_css_P.Gain2_Gain *
      rtb_DiscreteFIRFilter;
  }

  /* End of Outputs for SubSystem: '<Root>/Gyro Calibration' */

  /* S-Function (sfcn_A3_IN): '<Root>/Pushbutton A3' */
  sfcn_A3_IN_Outputs_wrapper( &MinSeg_Controller_css_B.PushbuttonA3,
    &MinSeg_Controller_css_DWork.PushbuttonA3_DSTATE);

  /* Logic: '<Root>/Logical Operator1' */
  MinSeg_Controller_css_B.LogicalOperator1 =
    !MinSeg_Controller_css_B.PushbuttonA3;

  /* Outputs for Enabled SubSystem: '<Root>/FSB Controller' incorporates:
   *  EnablePort: '<S3>/Enable'
   */
  if (Compare) {
    if (!MinSeg_Controller_css_DWork.FSBController_MODE) {
      /* InitializeConditions for DiscreteIntegrator: '<S3>/Discrete-Time  Integrator' */
      MinSeg_Controller_css_DWork.DiscreteTimeIntegrator_DSTATE =
        MinSeg_Controller_css_P.DiscreteTimeIntegrator_IC;

      /* S-Function Block: <S3>/Encoder SFunction */
      {
        real_T initVector[1] = { 0 };

        {
          int_T i1;
          for (i1=0; i1 < 1; i1++) {
            MinSeg_Controller_css_DWork.EncoderSFunction_DSTATE = initVector[0];
          }
        }
      }

      /* InitializeConditions for UnitDelay: '<S7>/UD' */
      MinSeg_Controller_css_DWork.UD_DSTATE =
        MinSeg_Controller_css_P.DiscreteDerivative_ICPrevScaled;

      /* InitializeConditions for DiscreteIntegrator: '<S9>/Discrete-Time  Integrator1' */
      MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[0] =
        MinSeg_Controller_css_P.DiscreteTimeIntegrator1_IC;
      MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[1] =
        MinSeg_Controller_css_P.DiscreteTimeIntegrator1_IC;
      MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[2] =
        MinSeg_Controller_css_P.DiscreteTimeIntegrator1_IC;
      MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[3] =
        MinSeg_Controller_css_P.DiscreteTimeIntegrator1_IC;
      MinSeg_Controller_css_DWork.FSBController_MODE = true;
    }
  } else {
    if (MinSeg_Controller_css_DWork.FSBController_MODE) {
      MinSeg_Controller_css_DWork.FSBController_MODE = false;
    }
  }

  if (MinSeg_Controller_css_DWork.FSBController_MODE) {
    /* Trigonometry: '<S13>/Trigonometric Function' incorporates:
     *  Constant: '<S13>/Y Bias'
     *  Constant: '<S13>/Z Bias'
     *  Gain: '<S13>/Gain1'
     *  Gain: '<S13>/Gain2'
     *  Product: '<S13>/Divide'
     *  Sum: '<S13>/Sum'
     *  Sum: '<S13>/Sum1'
     */
    MinSeg_Controller_css_B.angle_accel = atan(((real_T)((int32_T)
      MinSeg_Controller_css_P.Gain2_Gain_n *
      MinSeg_Controller_css_B.GyroDriverSFunction_o3) * 3.0517578125E-5 -
      MinSeg_Controller_css_P.ZBias_Value) / ((real_T)((int32_T)
      MinSeg_Controller_css_P.Gain1_Gain_j *
      MinSeg_Controller_css_B.GyroDriverSFunction_o2) * 3.0517578125E-5 -
      MinSeg_Controller_css_P.YBias_Value));

    /* DiscreteIntegrator: '<S3>/Discrete-Time  Integrator' */
    MinSeg_Controller_css_B.alpha =
      MinSeg_Controller_css_DWork.DiscreteTimeIntegrator_DSTATE;

    /* Gain: '<S3>/convert to  radians1' incorporates:
     *  Gain: '<S3>/convert to  radians2'
     *  Gain: '<S3>/convert to  radians3'
     *  Sum: '<S3>/Sum1'
     */
    MinSeg_Controller_css_B.converttoradians1 =
      (MinSeg_Controller_css_P.converttoradians3_Gain *
       MinSeg_Controller_css_B.angle_accel +
       MinSeg_Controller_css_P.converttoradians2_Gain *
       MinSeg_Controller_css_B.alpha) *
      MinSeg_Controller_css_P.converttoradians1_Gain;

    /* S-Function (sf_Encoder): '<S3>/Encoder SFunction' */
    sf_Encoder_Outputs_wrapper( &MinSeg_Controller_css_B.EncoderSFunction,
      &MinSeg_Controller_css_DWork.EncoderSFunction_DSTATE,
      &MinSeg_Controller_css_P.EncoderSFunction_P1, 1,
      &MinSeg_Controller_css_P.EncoderSFunction_P2, 1,
      &MinSeg_Controller_css_P.EncoderSFunction_P3, 1);

    /* Gain: '<S3>/convert to  radians' incorporates:
     *  DataTypeConversion: '<S3>/Data Type  Conversion2'
     */
    rtb_DiscreteFIRFilter = MinSeg_Controller_css_P.ES * (real_T)
      MinSeg_Controller_css_B.EncoderSFunction;

    /* Sum: '<S3>/Sum3' incorporates:
     *  Constant: '<S3>/Constant5'
     */
    MinSeg_Controller_css_B.Sum3 = (MinSeg_Controller_css_P.Constant5_Value +
      MinSeg_Controller_css_B.converttoradians1) + rtb_DiscreteFIRFilter;

    /* Gain: '<S3>/conver to radians//sec' incorporates:
     *  Sum: '<S3>/Sum'
     */
    MinSeg_Controller_css_B.convertoradianssec =
      (MinSeg_Controller_css_B.DataTypeConversion1 -
       MinSeg_Controller_css_B.Gain2) * -MinSeg_Controller_css_P.GS;

    /* SampleTimeMath: '<S7>/TSamp'
     *
     * About '<S7>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    MinSeg_Controller_css_B.TSamp = rtb_DiscreteFIRFilter *
      MinSeg_Controller_css_P.TSamp_WtEt;

    /* Sum: '<S3>/Sum4' incorporates:
     *  Sum: '<S7>/Diff'
     *  UnitDelay: '<S7>/UD'
     */
    MinSeg_Controller_css_B.Sum4 = (MinSeg_Controller_css_B.TSamp -
      MinSeg_Controller_css_DWork.UD_DSTATE) +
      MinSeg_Controller_css_B.convertoradianssec;

    /* ManualSwitch: '<S3>/Manual Switch' incorporates:
     *  Constant: '<S11>/Reference'
     *  Constant: '<S3>/Constant'
     *  DiscreteIntegrator: '<S9>/Discrete-Time  Integrator1'
     *  Gain: '<S11>/Gain1'
     *  Gain: '<S9>/LQR'
     *  Gain: '<S9>/LQR1'
     *  Product: '<S9>/Product'
     *  SignalConversion: '<S9>/TmpSignal ConversionAtLQRInport1'
     *  Sum: '<S11>/Add'
     *  Sum: '<S9>/Sum5'
     */
    if (MinSeg_Controller_css_P.ManualSwitch_CurrentSetting == 1) {
      MinSeg_Controller_css_B.u_Volts = MinSeg_Controller_css_P.Reference_Value
        - (((MinSeg_Controller_css_P.KLQRC[0] * MinSeg_Controller_css_B.Sum3 +
             MinSeg_Controller_css_P.KLQRC[1] * MinSeg_Controller_css_B.Sum4) +
            MinSeg_Controller_css_P.KLQRC[2] *
            MinSeg_Controller_css_B.converttoradians1) +
           MinSeg_Controller_css_P.KLQRC[3] *
           MinSeg_Controller_css_B.convertoradianssec);
    } else {
      MinSeg_Controller_css_B.u_Volts = (((MinSeg_Controller_css_P.KLQRC[0] *
        MinSeg_Controller_css_B.Sum3 + MinSeg_Controller_css_P.KLQRC[1] *
        MinSeg_Controller_css_B.Sum4) + MinSeg_Controller_css_P.KLQRC[2] *
        MinSeg_Controller_css_B.converttoradians1) +
        MinSeg_Controller_css_P.KLQRC[3] *
        MinSeg_Controller_css_B.convertoradianssec) *
        MinSeg_Controller_css_P.Constant_Value_f +
        (((MinSeg_Controller_css_P.Ki[0] *
           MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[0] +
           MinSeg_Controller_css_P.Ki[1] *
           MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[1]) +
          MinSeg_Controller_css_P.Ki[2] *
          MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[2]) +
         MinSeg_Controller_css_P.Ki[3] *
         MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[3]);
    }

    /* End of ManualSwitch: '<S3>/Manual Switch' */

    /* Logic: '<S3>/Logical Operator1' incorporates:
     *  Constant: '<S8>/Lower Limit'
     *  Constant: '<S8>/Upper Limit'
     *  Logic: '<S3>/Logical Operator'
     *  Logic: '<S8>/AND'
     *  RelationalOperator: '<S8>/Lower Test'
     *  RelationalOperator: '<S8>/Upper Test'
     */
    MinSeg_Controller_css_B.motor_Enable =
      ((MinSeg_Controller_css_P.IntervalTest1_lowlimit <
        MinSeg_Controller_css_B.angle_accel) &&
       (MinSeg_Controller_css_B.angle_accel <
        MinSeg_Controller_css_P.IntervalTest1_uplimit) &&
       (!MinSeg_Controller_css_B.LogicalOperator1));

    /* Gain: '<S12>/conversion to duty cycle (convert to int)' incorporates:
     *  Gain: '<S10>/Slider Gain'
     *  Product: '<S12>/Product1'
     */
    rtb_DiscreteFIRFilter = floor(MinSeg_Controller_css_P.SliderGain_gain *
      MinSeg_Controller_css_B.u_Volts * (real_T)
      MinSeg_Controller_css_B.motor_Enable * MinSeg_Controller_css_P.V2DCB);
    if (rtIsNaN(rtb_DiscreteFIRFilter) || rtIsInf(rtb_DiscreteFIRFilter)) {
      rtb_DiscreteFIRFilter = 0.0;
    } else {
      rtb_DiscreteFIRFilter = fmod(rtb_DiscreteFIRFilter, 65536.0);
    }

    i = rtb_DiscreteFIRFilter < 0.0 ? -(int16_T)(uint16_T)-rtb_DiscreteFIRFilter
      : (int16_T)(uint16_T)rtb_DiscreteFIRFilter;

    /* End of Gain: '<S12>/conversion to duty cycle (convert to int)' */

    /* Switch: '<S12>/Switch' incorporates:
     *  Constant: '<S12>/Constant1'
     *  Constant: '<S12>/Constant2'
     */
    if (i >= MinSeg_Controller_css_P.Switch_Threshold) {
      rtb_DiscreteFIRFilter = MinSeg_Controller_css_P.Constant2_Value;
    } else {
      rtb_DiscreteFIRFilter = MinSeg_Controller_css_P.Constant1_Value;
    }

    /* End of Switch: '<S12>/Switch' */

    /* DataTypeConversion: '<S14>/Data Type Conversion' */
    if (rtb_DiscreteFIRFilter < 256.0) {
      if (rtb_DiscreteFIRFilter >= 0.0) {
        MinSeg_Controller_css_B.DataTypeConversion = (uint8_T)
          rtb_DiscreteFIRFilter;
      } else {
        MinSeg_Controller_css_B.DataTypeConversion = 0U;
      }
    } else {
      MinSeg_Controller_css_B.DataTypeConversion = MAX_uint8_T;
    }

    /* End of DataTypeConversion: '<S14>/Data Type Conversion' */

    /* S-Function (arduinodigitaloutput_sfcn): '<S14>/Digital Output' */
    MW_digitalWrite(MinSeg_Controller_css_P.DigitalOutput_pinNumber,
                    MinSeg_Controller_css_B.DataTypeConversion);

    /* Abs: '<S12>/Abs' */
    if (i < 0) {
      i = -i;
    }

    /* End of Abs: '<S12>/Abs' */

    /* Sum: '<S12>/Add2' incorporates:
     *  Constant: '<S12>/Constant3'
     */
    u0 = MinSeg_Controller_css_P.Constant3_Value + (real_T)i;

    /* Saturate: '<S12>/Saturation 0 to 255' */
    if (u0 > MinSeg_Controller_css_P.Saturation0to255_UpperSat) {
      u0 = MinSeg_Controller_css_P.Saturation0to255_UpperSat;
    } else {
      if (u0 < MinSeg_Controller_css_P.Saturation0to255_LowerSat) {
        u0 = MinSeg_Controller_css_P.Saturation0to255_LowerSat;
      }
    }

    /* DataTypeConversion: '<S15>/Data Type Conversion' incorporates:
     *  Abs: '<S12>/Abs3'
     *  Gain: '<S12>/Gain1'
     *  Saturate: '<S12>/Saturation 0 to 255'
     *  Sum: '<S12>/Add1'
     */
    rtb_DiscreteFIRFilter = fabs(MinSeg_Controller_css_P.Gain1_Gain *
      rtb_DiscreteFIRFilter - u0);
    if (rtb_DiscreteFIRFilter < 256.0) {
      MinSeg_Controller_css_B.DataTypeConversion_c = (uint8_T)
        rtb_DiscreteFIRFilter;
    } else {
      MinSeg_Controller_css_B.DataTypeConversion_c = MAX_uint8_T;
    }

    /* End of DataTypeConversion: '<S15>/Data Type Conversion' */

    /* S-Function (arduinoanalogoutput_sfcn): '<S15>/PWM' */
    MW_analogWrite(MinSeg_Controller_css_P.PWM_pinNumber,
                   MinSeg_Controller_css_B.DataTypeConversion_c);
  }

  /* End of Outputs for SubSystem: '<Root>/FSB Controller' */
}

/* Model update function */
void MinSeg_Controller_css_update(void)
{
  /* Update for Delay: '<Root>/Delay' */
  MinSeg_Controller_css_DWork.Delay_DSTATE =
    MinSeg_Controller_css_B.LogicalOperator1;

  /* Update for Memory: '<S16>/IC=ic' */
  MinSeg_Controller_css_DWork.ICic_PreviousInput =
    MinSeg_Controller_css_B.Switch;

  /* Update for Enabled SubSystem: '<Root>/Clear 13 ' incorporates:
   *  Update for EnablePort: '<S1>/Enable'
   */
  if (MinSeg_Controller_css_DWork.Clear13_MODE) {
    /* S-Function "sfcn_Digital_Out_wrapper" Block: <S1>/S-Function Builder */
    sfcn_Digital_Out_Update_wrapper
      (&MinSeg_Controller_css_B.DataTypeConversion_e,
       &MinSeg_Controller_css_DWork.SFunctionBuilder_DSTATE,
       &MinSeg_Controller_css_P.SFunctionBuilder_P1, 1);
  }

  /* End of Update for SubSystem: '<Root>/Clear 13 ' */

  /* S-Function "sf_MPU6050_Driver_GxAyz_wrapper" Block: <Root>/Gyro Driver SFunction */
  sf_MPU6050_Driver_GxAyz_Update_wrapper
    ( &MinSeg_Controller_css_B.GyroDriverSFunction_o1,
     &MinSeg_Controller_css_B.GyroDriverSFunction_o2,
     &MinSeg_Controller_css_B.GyroDriverSFunction_o3,
     &MinSeg_Controller_css_DWork.GyroDriverSFunction_DSTATE);

  /* Update for Enabled SubSystem: '<Root>/Gyro Calibration' incorporates:
   *  Update for EnablePort: '<S4>/Enable'
   */
  if (MinSeg_Controller_css_DWork.GyroCalibration_MODE) {
    /* Update for DiscreteFir: '<S4>/Discrete FIR Filter' */
    /* Update circular buffer index */
    MinSeg_Controller_css_DWork.DiscreteFIRFilter_circBuf--;
    if (MinSeg_Controller_css_DWork.DiscreteFIRFilter_circBuf < 0L) {
      MinSeg_Controller_css_DWork.DiscreteFIRFilter_circBuf = 98L;
    }

    /* Update circular buffer */
    MinSeg_Controller_css_DWork.DiscreteFIRFilter_states[MinSeg_Controller_css_DWork.DiscreteFIRFilter_circBuf]
      = MinSeg_Controller_css_B.DataTypeConversion1;

    /* End of Update for DiscreteFir: '<S4>/Discrete FIR Filter' */
  }

  /* End of Update for SubSystem: '<Root>/Gyro Calibration' */

  /* S-Function "sfcn_A3_IN_wrapper" Block: <Root>/Pushbutton A3 */
  sfcn_A3_IN_Update_wrapper( &MinSeg_Controller_css_B.PushbuttonA3,
    &MinSeg_Controller_css_DWork.PushbuttonA3_DSTATE);

  /* Update for Enabled SubSystem: '<Root>/FSB Controller' incorporates:
   *  Update for EnablePort: '<S3>/Enable'
   */
  if (MinSeg_Controller_css_DWork.FSBController_MODE) {
    /* Update for DiscreteIntegrator: '<S3>/Discrete-Time  Integrator' */
    MinSeg_Controller_css_DWork.DiscreteTimeIntegrator_DSTATE +=
      MinSeg_Controller_css_P.DiscreteTimeIntegrator_gainval *
      MinSeg_Controller_css_B.convertoradianssec;

    /* S-Function "sf_Encoder_wrapper" Block: <S3>/Encoder SFunction */
    sf_Encoder_Update_wrapper( &MinSeg_Controller_css_B.EncoderSFunction,
      &MinSeg_Controller_css_DWork.EncoderSFunction_DSTATE,
      &MinSeg_Controller_css_P.EncoderSFunction_P1, 1,
      &MinSeg_Controller_css_P.EncoderSFunction_P2, 1,
      &MinSeg_Controller_css_P.EncoderSFunction_P3, 1);

    /* Update for UnitDelay: '<S7>/UD' */
    MinSeg_Controller_css_DWork.UD_DSTATE = MinSeg_Controller_css_B.TSamp;

    /* Update for DiscreteIntegrator: '<S9>/Discrete-Time  Integrator1' */
    MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[0] +=
      MinSeg_Controller_css_P.DiscreteTimeIntegrator1_gainval *
      MinSeg_Controller_css_B.Sum3;
    MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[1] +=
      MinSeg_Controller_css_P.DiscreteTimeIntegrator1_gainval *
      MinSeg_Controller_css_B.Sum4;
    MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[2] +=
      MinSeg_Controller_css_P.DiscreteTimeIntegrator1_gainval *
      MinSeg_Controller_css_B.converttoradians1;
    MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[3] +=
      MinSeg_Controller_css_P.DiscreteTimeIntegrator1_gainval *
      MinSeg_Controller_css_B.convertoradianssec;
  }

  /* End of Update for SubSystem: '<Root>/FSB Controller' */

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  MinSeg_Controller_css_M->Timing.t[0] =
    (++MinSeg_Controller_css_M->Timing.clockTick0) *
    MinSeg_Controller_css_M->Timing.stepSize0;

  {
    /* Update absolute timer for sample time: [0.0024s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.0024, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    MinSeg_Controller_css_M->Timing.clockTick1++;
  }
}

/* Model initialize function */
void MinSeg_Controller_css_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)MinSeg_Controller_css_M, 0,
                sizeof(RT_MODEL_MinSeg_Controller_css));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&MinSeg_Controller_css_M->solverInfo,
                          &MinSeg_Controller_css_M->Timing.simTimeStep);
    rtsiSetTPtr(&MinSeg_Controller_css_M->solverInfo, &rtmGetTPtr
                (MinSeg_Controller_css_M));
    rtsiSetStepSizePtr(&MinSeg_Controller_css_M->solverInfo,
                       &MinSeg_Controller_css_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&MinSeg_Controller_css_M->solverInfo, ((const char_T **)
                           (&rtmGetErrorStatus(MinSeg_Controller_css_M))));
    rtsiSetRTModelPtr(&MinSeg_Controller_css_M->solverInfo,
                      MinSeg_Controller_css_M);
  }

  rtsiSetSimTimeStep(&MinSeg_Controller_css_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&MinSeg_Controller_css_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(MinSeg_Controller_css_M, &MinSeg_Controller_css_M->Timing.tArray[0]);
  MinSeg_Controller_css_M->Timing.stepSize0 = 0.0024;

  /* block I/O */
  (void) memset(((void *) &MinSeg_Controller_css_B), 0,
                sizeof(BlockIO_MinSeg_Controller_css));

  /* states (dwork) */
  (void) memset((void *)&MinSeg_Controller_css_DWork, 0,
                sizeof(D_Work_MinSeg_Controller_css));

  {
    int16_T i;

    /* InitializeConditions for Enabled SubSystem: '<Root>/Clear 13 ' */

    /* S-Function Block: <S1>/S-Function Builder */
    {
      real_T initVector[1] = { 0 };

      {
        int_T i1;
        for (i1=0; i1 < 1; i1++) {
          MinSeg_Controller_css_DWork.SFunctionBuilder_DSTATE = initVector[0];
        }
      }
    }

    /* End of InitializeConditions for SubSystem: '<Root>/Clear 13 ' */

    /* InitializeConditions for Enabled SubSystem: '<Root>/Gyro Calibration' */
    /* InitializeConditions for DiscreteFir: '<S4>/Discrete FIR Filter' */
    MinSeg_Controller_css_DWork.DiscreteFIRFilter_circBuf = 0L;
    for (i = 0; i < 99; i++) {
      MinSeg_Controller_css_DWork.DiscreteFIRFilter_states[i] =
        MinSeg_Controller_css_P.DiscreteFIRFilter_InitialStates;
    }

    /* End of InitializeConditions for DiscreteFir: '<S4>/Discrete FIR Filter' */
    /* End of InitializeConditions for SubSystem: '<Root>/Gyro Calibration' */

    /* Start for Enabled SubSystem: '<Root>/FSB Controller' */
    /* Start for S-Function (arduinodigitaloutput_sfcn): '<S14>/Digital Output' */
    MW_pinModeOutput(MinSeg_Controller_css_P.DigitalOutput_pinNumber);

    /* Start for S-Function (arduinoanalogoutput_sfcn): '<S15>/PWM' */
    MW_pinModeOutput(MinSeg_Controller_css_P.PWM_pinNumber);

    /* End of Start for SubSystem: '<Root>/FSB Controller' */

    /* InitializeConditions for Enabled SubSystem: '<Root>/FSB Controller' */
    /* InitializeConditions for DiscreteIntegrator: '<S3>/Discrete-Time  Integrator' */
    MinSeg_Controller_css_DWork.DiscreteTimeIntegrator_DSTATE =
      MinSeg_Controller_css_P.DiscreteTimeIntegrator_IC;

    /* S-Function Block: <S3>/Encoder SFunction */
    {
      real_T initVector[1] = { 0 };

      {
        int_T i1;
        for (i1=0; i1 < 1; i1++) {
          MinSeg_Controller_css_DWork.EncoderSFunction_DSTATE = initVector[0];
        }
      }
    }

    /* InitializeConditions for UnitDelay: '<S7>/UD' */
    MinSeg_Controller_css_DWork.UD_DSTATE =
      MinSeg_Controller_css_P.DiscreteDerivative_ICPrevScaled;

    /* InitializeConditions for DiscreteIntegrator: '<S9>/Discrete-Time  Integrator1' */
    MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[0] =
      MinSeg_Controller_css_P.DiscreteTimeIntegrator1_IC;
    MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[1] =
      MinSeg_Controller_css_P.DiscreteTimeIntegrator1_IC;
    MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[2] =
      MinSeg_Controller_css_P.DiscreteTimeIntegrator1_IC;
    MinSeg_Controller_css_DWork.DiscreteTimeIntegrator1_DSTATE[3] =
      MinSeg_Controller_css_P.DiscreteTimeIntegrator1_IC;

    /* End of InitializeConditions for SubSystem: '<Root>/FSB Controller' */

    /* InitializeConditions for Delay: '<Root>/Delay' */
    MinSeg_Controller_css_DWork.Delay_DSTATE =
      MinSeg_Controller_css_P.Delay_InitialCondition;

    /* InitializeConditions for Memory: '<S16>/IC=ic' */
    MinSeg_Controller_css_DWork.ICic_PreviousInput =
      MinSeg_Controller_css_P.SampleandHold_ic;

    /* S-Function Block: <Root>/Gyro Driver SFunction */
    {
      real_T initVector[1] = { 0 };

      {
        int_T i1;
        for (i1=0; i1 < 1; i1++) {
          MinSeg_Controller_css_DWork.GyroDriverSFunction_DSTATE = initVector[0];
        }
      }
    }

    /* S-Function Block: <Root>/Pushbutton A3 */
    {
      real_T initVector[1] = { 0 };

      {
        int_T i1;
        for (i1=0; i1 < 1; i1++) {
          MinSeg_Controller_css_DWork.PushbuttonA3_DSTATE = initVector[0];
        }
      }
    }
  }
}

/* Model terminate function */
void MinSeg_Controller_css_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
