/*
 * File: MinSeg_Controller_css_data.c
 *
 * Code generated for Simulink model 'MinSeg_Controller_css'.
 *
 * Model version                  : 1.102
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * TLC version                    : 8.7 (Aug  5 2014)
 * C/C++ source code generated on : Wed Mar 11 17:56:19 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MinSeg_Controller_css.h"
#include "MinSeg_Controller_css_private.h"

/* Block parameters (auto storage) */
Parameters_MinSeg_Controller_cs MinSeg_Controller_css_P = {
  -0.0087266462599716477,              /* Variable: ES
                                        * Referenced by: '<S3>/convert to  radians'
                                        */
  0.00015583296892806512,              /* Variable: GS
                                        * Referenced by: '<S3>/conver to radians//sec'
                                        */

  /*  Variable: KLQRC
   * Referenced by:
   *   '<S9>/LQR'
   *   '<S11>/Gain1'
   */
  { -0.21000000000000002, -1.4847021000000002, -95.8299, -13.6744 },

  /*  Variable: Ki
   * Referenced by: '<S9>/LQR1'
   */
  { -0.021, -0.0, 1.0, 0.0 },
  28.333333333333332,                  /* Variable: V2DCB
                                        * Referenced by: '<S12>/conversion to duty cycle (convert to int)'
                                        */
  2.0,                                 /* Variable: tstart
                                        * Referenced by:
                                        *   '<S2>/Constant'
                                        *   '<S5>/Lower Limit'
                                        *   '<S5>/Upper Limit'
                                        */
  0.0,                                 /* Mask Parameter: DiscreteDerivative_ICPrevScaled
                                        * Referenced by: '<S7>/UD'
                                        */
  0.4,                                 /* Mask Parameter: SliderGain_gain
                                        * Referenced by: '<S10>/Slider Gain'
                                        */
  0.0,                                 /* Mask Parameter: SampleandHold_ic
                                        * Referenced by: '<S16>/IC=ic'
                                        */
  -0.75,                               /* Mask Parameter: IntervalTest1_lowlimit
                                        * Referenced by: '<S8>/Lower Limit'
                                        */
  0.75,                                /* Mask Parameter: IntervalTest1_uplimit
                                        * Referenced by: '<S8>/Upper Limit'
                                        */
  6U,                                  /* Mask Parameter: DigitalOutput_pinNumber
                                        * Referenced by: '<S14>/Digital Output'
                                        */
  8U,                                  /* Mask Parameter: PWM_pinNumber
                                        * Referenced by: '<S15>/PWM'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Constant'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S12>/Constant2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S11>/Reference'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S3>/Constant5'
                                        */
  1430.0,                              /* Expression: 1430
                                        * Referenced by: '<S13>/Z Bias'
                                        */
  101.0,                               /* Expression: 101
                                        * Referenced by: '<S13>/Y Bias'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S3>/convert to  radians3'
                                        */
  0.0024,                              /* Computed Parameter: DiscreteTimeIntegrator_gainval
                                        * Referenced by: '<S3>/Discrete-Time  Integrator'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S3>/Discrete-Time  Integrator'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S3>/convert to  radians2'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S3>/convert to  radians1'
                                        */
  416.66666666666669,                  /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S7>/TSamp'
                                        */
  0.0024,                              /* Computed Parameter: DiscreteTimeIntegrator1_gainval
                                        * Referenced by: '<S9>/Discrete-Time  Integrator1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S9>/Discrete-Time  Integrator1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S3>/Constant'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S12>/Constant1'
                                        */
  10.0,                                /* Expression: 10
                                        * Referenced by: '<S12>/Constant3'
                                        */
  255.0,                               /* Expression: 255
                                        * Referenced by: '<S12>/Saturation 0 to 255'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S12>/Saturation 0 to 255'
                                        */
  255.0,                               /* Expression: 255
                                        * Referenced by: '<S12>/Gain1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/Discrete FIR Filter'
                                        */

  /*  Expression: ones(1,100)
   * Referenced by: '<S4>/Discrete FIR Filter'
   */
  { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 },
  0.01,                                /* Expression: 1/100
                                        * Referenced by: '<S4>/Gain2'
                                        */
  0,                                   /* Computed Parameter: Switch_Threshold
                                        * Referenced by: '<S12>/Switch'
                                        */
  1U,                                  /* Computed Parameter: Delay_DelayLength
                                        * Referenced by: '<Root>/Delay'
                                        */
  -32768,                              /* Computed Parameter: Gain2_Gain_n
                                        * Referenced by: '<S13>/Gain2'
                                        */
  -32768,                              /* Computed Parameter: Gain1_Gain_j
                                        * Referenced by: '<S13>/Gain1'
                                        */
  13U,                                 /* Expression: uint8(13)
                                        * Referenced by: '<S1>/S-Function Builder'
                                        */
  0U,                                  /* Expression: uint8(0)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  18U,                                 /* Expression: uint8(18)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  19U,                                 /* Expression: uint8(19)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  0U,                                  /* Computed Parameter: ManualSwitch_CurrentSetting
                                        * Referenced by: '<S3>/Manual Switch'
                                        */
  0                                    /* Computed Parameter: Delay_InitialCondition
                                        * Referenced by: '<Root>/Delay'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
