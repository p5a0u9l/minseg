
Arduino Driver for the HC-SR04 ultrasonic distance sensor. 

** General Usage: **

The wiring for the HCSR04 only requires power, ground, and two digital pins on the Arduino for the echo and trigger pins on the HC-SR04 sensor.

Currently the digital lines are hard coded to pin 6 for the tirgger and pin 7 for the echo.  To change the pins the SFunction must be recompiled.  Instructions are provided below.

This folder contains compiled versions of the Sfunction for 32 and 64 bit platforms: sf_HCSR04.mexw32, sf_HCSR04.mexw64
you can run the build the code without having to compile the SFunction block:

If Matlab is in this directory:
	- Open HCSR04_SFunction.slx 
	- Select Tools -> Run on Target Hardware -> Run (or Control-B to build and download, then "connect to target" to connect)
	Note: Only a mega board will allow you to connect to the board in external mode.  On other boards it will simply run the code
	In this case use the serial port to send your data and verify.  (for help email us at info@MinSeg.com) 

Compiling the SFunction requires an installed compiler (see http://www.mathworks.com/support/compilers/current_release/)

Instructions to compile the s-function:
	Files Required: (all must be in the same directory as the simulink file)
	- HCSR04_SFunction.slx 
	- NewPing.cpp
	- NewPing.h
	- I2Cdev.cpp

	
	Simulink Settings:
	- Make sure the Configuration Parameters are set to the correct COM port for your Arduino.
	
	Compile Instructions:
	- Open the HCSR04_SFunction.slx simulink diagram
	- Make sure the Matlab current directory is in the same file directory as this simulink diagram
	- Open the sf_HCSR04 SFunction in the simulink diagram
	- Click Build
	- In the same directory one of the files created will be sf_HCSR04_wrapper.c
	- rename this file to sf_HCSR04_wrapper.cpp
	- open this file so you can edit it (sf_HCSR04_wrapper.cpp)
	- Modify the two lines in this file by adding 'extern "C"' to the beginning of them as follows:
		* void sf_HCSR04_Outputs_wrapper(...   to
		  extern "C" void sf_HCSR04_Outputs_wrapper(...
		* void sf_HCSR04_Update_wrapper(...   to
		  extern "C" void sf_HCSR04_Update_wrapper(
	- Build your Simulink Diagram: "Ctrl-B" or 
	- Connect To Target to view the data on the scope
	
For distribution WITHOUT requiring a separately installed compiler:
If you wish to distribute the driver to students without requiring them to have a compiler installed you must include all the original files and 3 additional files:
	- HCSR04_SFunction.slx 
	- NewPing.cpp
	- NewPing.h
	- SF_HCSR04_wrapper.cpp
	- sf_HCSR04.tlc
	- sf_HCSR04.mexw64 or sf_HCSR04.mexw32
Note that you must compile the SFunction and distribute the correct mex file for the appropriate hardware (32 bit or 64 bit machine).

This example runs the code on the arduino in external mode. (See Configuration Parameters on the simulink diagram)

Questions? Contact us at info@MinSeg.com


		  