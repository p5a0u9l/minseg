/*
 * File: MinSeg_Controller_types.h
 *
 * Code generated for Simulink model 'MinSeg_Controller'.
 *
 * Model version                  : 1.84
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * TLC version                    : 8.7 (Aug  5 2014)
 * C/C++ source code generated on : Sat Mar 07 15:57:43 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MinSeg_Controller_types_h_
#define RTW_HEADER_MinSeg_Controller_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Parameters (auto storage) */
typedef struct Parameters_MinSeg_Controller_ Parameters_MinSeg_Controller;

/* Forward declaration for rtModel */
typedef struct tag_RTM_MinSeg_Controller RT_MODEL_MinSeg_Controller;

#endif                                 /* RTW_HEADER_MinSeg_Controller_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
