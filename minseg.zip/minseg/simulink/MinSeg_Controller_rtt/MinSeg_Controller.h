/*
 * File: MinSeg_Controller.h
 *
 * Code generated for Simulink model 'MinSeg_Controller'.
 *
 * Model version                  : 1.84
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * TLC version                    : 8.7 (Aug  5 2014)
 * C/C++ source code generated on : Sat Mar 07 15:57:43 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MinSeg_Controller_h_
#define RTW_HEADER_MinSeg_Controller_h_
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef MinSeg_Controller_COMMON_INCLUDES_
# define MinSeg_Controller_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "dt_info.h"
#include "ext_work.h"
#include "arduino_analoginput_lct.h"
#include "arduino_digitaloutput_lct.h"
#include "arduino_analogoutput_lct.h"
#endif                                 /* MinSeg_Controller_COMMON_INCLUDES_ */

#include "MinSeg_Controller_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

/* Block signals (auto storage) */
typedef struct {
  real_T Switch;                       /* '<S17>/Switch' */
  real_T Add;                          /* '<Root>/Add' */
  real_T DataTypeConversion1;          /* '<Root>/Data Type  Conversion1' */
  real_T Gain2;                        /* '<S4>/Gain2' */
  real_T angle_accel;                  /* '<S14>/Trigonometric Function' */
  real_T alpha;                        /* '<S3>/Discrete-Time  Integrator' */
  real_T converttoradians1;            /* '<S3>/convert to  radians1' */
  real_T Sum3;                         /* '<S3>/Sum3' */
  real_T convertoradianssec;           /* '<S3>/conver to radians//sec' */
  real_T TSamp;                        /* '<S7>/TSamp' */
  real_T Sum4;                         /* '<S3>/Sum4' */
  real_T Fcn1;                         /* '<S10>/Fcn1' */
  real_T u_Volts;                      /* '<S3>/Manual Switch' */
  int16_T GyroDriverSFunction_o1;      /* '<Root>/Gyro Driver SFunction' */
  int16_T GyroDriverSFunction_o2;      /* '<Root>/Gyro Driver SFunction' */
  int16_T GyroDriverSFunction_o3;      /* '<Root>/Gyro Driver SFunction' */
  int16_T EncoderSFunction;            /* '<S3>/Encoder SFunction' */
  uint8_T DataTypeConversion;          /* '<S15>/Data Type Conversion' */
  uint8_T DataTypeConversion_c;        /* '<S16>/Data Type Conversion' */
  boolean_T PushbuttonA3;              /* '<Root>/Pushbutton A3' */
  boolean_T LogicalOperator1;          /* '<Root>/Logical Operator1' */
  boolean_T motor_Enable;              /* '<S3>/Logical Operator1' */
  boolean_T DataTypeConversion_e;      /* '<S1>/Data Type Conversion' */
} BlockIO_MinSeg_Controller;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T GyroDriverSFunction_DSTATE;   /* '<Root>/Gyro Driver SFunction' */
  real_T PushbuttonA3_DSTATE;          /* '<Root>/Pushbutton A3' */
  real_T DiscreteFIRFilter_states[99]; /* '<S4>/Discrete FIR Filter' */
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S3>/Discrete-Time  Integrator' */
  real_T EncoderSFunction_DSTATE;      /* '<S3>/Encoder SFunction' */
  real_T UD_DSTATE;                    /* '<S7>/UD' */
  real_T DiscreteTimeIntegrator1_DSTATE[4];/* '<S9>/Discrete-Time  Integrator1' */
  real_T SFunctionBuilder_DSTATE;      /* '<S1>/S-Function Builder' */
  real_T ICic_PreviousInput;           /* '<S17>/IC=ic' */
  struct {
    void *LoggedData;
  } Scope_PWORK;                       /* '<S10>/Scope' */

  struct {
    void *LoggedData;
  } VoltsandEnableScope_PWORK;         /* '<S3>/Volts and Enable Scope' */

  struct {
    void *LoggedData;
  } gyrovsaccelangle_PWORK;            /* '<S3>/gyro vs accel angle' */

  int32_T DiscreteFIRFilter_circBuf;   /* '<S4>/Discrete FIR Filter' */
  boolean_T Delay_DSTATE;              /* '<Root>/Delay' */
  int8_T Clear13_SubsysRanBC;          /* '<Root>/Clear 13 ' */
  int8_T GyroCalibration_SubsysRanBC;  /* '<Root>/Gyro Calibration' */
  int8_T FSBController_SubsysRanBC;    /* '<Root>/FSB Controller' */
  boolean_T Clear13_MODE;              /* '<Root>/Clear 13 ' */
  boolean_T GyroCalibration_MODE;      /* '<Root>/Gyro Calibration' */
  boolean_T FSBController_MODE;        /* '<Root>/FSB Controller' */
} D_Work_MinSeg_Controller;

/* Parameters (auto storage) */
struct Parameters_MinSeg_Controller_ {
  real_T ES;                           /* Variable: ES
                                        * Referenced by: '<S3>/convert to  radians'
                                        */
  real_T GS;                           /* Variable: GS
                                        * Referenced by: '<S3>/conver to radians//sec'
                                        */
  real_T K[4];                         /* Variable: K
                                        * Referenced by: '<S12>/Gain1'
                                        */
  real_T KLQRC[4];                     /* Variable: KLQRC
                                        * Referenced by: '<S9>/LQR'
                                        */
  real_T Ki[4];                        /* Variable: Ki
                                        * Referenced by: '<S9>/LQR1'
                                        */
  real_T V2DCB;                        /* Variable: V2DCB
                                        * Referenced by: '<S13>/conversion to duty cycle (convert to int)'
                                        */
  real_T tstart;                       /* Variable: tstart
                                        * Referenced by:
                                        *   '<S2>/Constant'
                                        *   '<S5>/Lower Limit'
                                        *   '<S5>/Upper Limit'
                                        */
  real_T DiscreteDerivative_ICPrevScaled;/* Mask Parameter: DiscreteDerivative_ICPrevScaled
                                          * Referenced by: '<S7>/UD'
                                          */
  real_T SliderGain2_gain;             /* Mask Parameter: SliderGain2_gain
                                        * Referenced by: '<S11>/Slider Gain'
                                        */
  real_T SampleandHold_ic;             /* Mask Parameter: SampleandHold_ic
                                        * Referenced by: '<S17>/IC=ic'
                                        */
  real_T IntervalTest1_lowlimit;       /* Mask Parameter: IntervalTest1_lowlimit
                                        * Referenced by: '<S8>/Lower Limit'
                                        */
  real_T IntervalTest1_uplimit;        /* Mask Parameter: IntervalTest1_uplimit
                                        * Referenced by: '<S8>/Upper Limit'
                                        */
  uint32_T DigitalOutput_pinNumber;    /* Mask Parameter: DigitalOutput_pinNumber
                                        * Referenced by: '<S15>/Digital Output'
                                        */
  uint32_T PWM_pinNumber;              /* Mask Parameter: PWM_pinNumber
                                        * Referenced by: '<S16>/PWM'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S1>/Constant'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S13>/Constant2'
                                        */
  real_T Reference_Value;              /* Expression: 0
                                        * Referenced by: '<S12>/Reference'
                                        */
  real_T Constant5_Value;              /* Expression: 0
                                        * Referenced by: '<S3>/Constant5'
                                        */
  real_T ZBias_Value;                  /* Expression: 1430
                                        * Referenced by: '<S14>/Z Bias'
                                        */
  real_T YBias_Value;                  /* Expression: 101
                                        * Referenced by: '<S14>/Y Bias'
                                        */
  real_T converttoradians3_Gain;       /* Expression: .8
                                        * Referenced by: '<S3>/convert to  radians3'
                                        */
  real_T DiscreteTimeIntegrator_gainval;/* Computed Parameter: DiscreteTimeIntegrator_gainval
                                         * Referenced by: '<S3>/Discrete-Time  Integrator'
                                         */
  real_T DiscreteTimeIntegrator_IC;    /* Expression: 0
                                        * Referenced by: '<S3>/Discrete-Time  Integrator'
                                        */
  real_T converttoradians2_Gain;       /* Expression: .2
                                        * Referenced by: '<S3>/convert to  radians2'
                                        */
  real_T converttoradians1_Gain;       /* Expression: 1
                                        * Referenced by: '<S3>/convert to  radians1'
                                        */
  real_T TSamp_WtEt;                   /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S7>/TSamp'
                                        */
  real_T DiscreteTimeIntegrator1_gainval;/* Computed Parameter: DiscreteTimeIntegrator1_gainval
                                          * Referenced by: '<S9>/Discrete-Time  Integrator1'
                                          */
  real_T DiscreteTimeIntegrator1_IC;   /* Expression: 0
                                        * Referenced by: '<S9>/Discrete-Time  Integrator1'
                                        */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S13>/Constant1'
                                        */
  real_T Constant3_Value;              /* Expression: 10
                                        * Referenced by: '<S13>/Constant3'
                                        */
  real_T Saturation0to255_UpperSat;    /* Expression: 255
                                        * Referenced by: '<S13>/Saturation 0 to 255'
                                        */
  real_T Saturation0to255_LowerSat;    /* Expression: 0
                                        * Referenced by: '<S13>/Saturation 0 to 255'
                                        */
  real_T Gain1_Gain;                   /* Expression: 255
                                        * Referenced by: '<S13>/Gain1'
                                        */
  real_T DiscreteFIRFilter_InitialStates;/* Expression: 0
                                          * Referenced by: '<S4>/Discrete FIR Filter'
                                          */
  real_T DiscreteFIRFilter_Coefficients[100];/* Expression: ones(1,100)
                                              * Referenced by: '<S4>/Discrete FIR Filter'
                                              */
  real_T Gain2_Gain;                   /* Expression: 1/100
                                        * Referenced by: '<S4>/Gain2'
                                        */
  uint32_T GainAdjust1_p1;             /* Computed Parameter: GainAdjust1_p1
                                        * Referenced by: '<S10>/Gain Adjust1'
                                        */
  int16_T Switch_Threshold;            /* Computed Parameter: Switch_Threshold
                                        * Referenced by: '<S13>/Switch'
                                        */
  uint16_T Delay_DelayLength;          /* Computed Parameter: Delay_DelayLength
                                        * Referenced by: '<Root>/Delay'
                                        */
  int16_T Gain2_Gain_n;                /* Computed Parameter: Gain2_Gain_n
                                        * Referenced by: '<S14>/Gain2'
                                        */
  int16_T Gain1_Gain_j;                /* Computed Parameter: Gain1_Gain_j
                                        * Referenced by: '<S14>/Gain1'
                                        */
  uint8_T SFunctionBuilder_P1;         /* Expression: uint8(13)
                                        * Referenced by: '<S1>/S-Function Builder'
                                        */
  uint8_T EncoderSFunction_P1;         /* Expression: uint8(0)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  uint8_T EncoderSFunction_P2;         /* Expression: uint8(18)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  uint8_T EncoderSFunction_P3;         /* Expression: uint8(19)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  uint8_T ManualSwitch_CurrentSetting; /* Computed Parameter: ManualSwitch_CurrentSetting
                                        * Referenced by: '<S3>/Manual Switch'
                                        */
  boolean_T Delay_InitialCondition;    /* Computed Parameter: Delay_InitialCondition
                                        * Referenced by: '<Root>/Delay'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_MinSeg_Controller {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (auto storage) */
extern Parameters_MinSeg_Controller MinSeg_Controller_P;

/* Block signals (auto storage) */
extern BlockIO_MinSeg_Controller MinSeg_Controller_B;

/* Block states (auto storage) */
extern D_Work_MinSeg_Controller MinSeg_Controller_DWork;

/* Model entry point functions */
extern void MinSeg_Controller_initialize(void);
extern void MinSeg_Controller_output(void);
extern void MinSeg_Controller_update(void);
extern void MinSeg_Controller_terminate(void);

/* Real-time Model object */
extern RT_MODEL_MinSeg_Controller *const MinSeg_Controller_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'MinSeg_Controller'
 * '<S1>'   : 'MinSeg_Controller/Clear 13 '
 * '<S2>'   : 'MinSeg_Controller/Compare To Constant'
 * '<S3>'   : 'MinSeg_Controller/FSB Controller'
 * '<S4>'   : 'MinSeg_Controller/Gyro Calibration'
 * '<S5>'   : 'MinSeg_Controller/Interval Test'
 * '<S6>'   : 'MinSeg_Controller/Sample and Hold'
 * '<S7>'   : 'MinSeg_Controller/FSB Controller/Discrete  Derivative'
 * '<S8>'   : 'MinSeg_Controller/FSB Controller/Interval Test1'
 * '<S9>'   : 'MinSeg_Controller/FSB Controller/LQR Controller'
 * '<S10>'  : 'MinSeg_Controller/FSB Controller/Potentiometer Gain Adjust'
 * '<S11>'  : 'MinSeg_Controller/FSB Controller/Slider Gain2'
 * '<S12>'  : 'MinSeg_Controller/FSB Controller/State Feedback Controller'
 * '<S13>'  : 'MinSeg_Controller/FSB Controller/Volts To Adruino PWM 754410 and Motor'
 * '<S14>'  : 'MinSeg_Controller/FSB Controller/angle_trigonometry'
 * '<S15>'  : 'MinSeg_Controller/FSB Controller/Volts To Adruino PWM 754410 and Motor/Digital Output1'
 * '<S16>'  : 'MinSeg_Controller/FSB Controller/Volts To Adruino PWM 754410 and Motor/PWM'
 * '<S17>'  : 'MinSeg_Controller/Sample and Hold/Model'
 */
#endif                                 /* RTW_HEADER_MinSeg_Controller_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
