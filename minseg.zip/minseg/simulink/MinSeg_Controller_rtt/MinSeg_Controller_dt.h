/*
 * MinSeg_Controller_dt.h
 *
 * Code generation for model "MinSeg_Controller".
 *
 * Model version              : 1.84
 * Simulink Coder version : 8.7 (R2014b) 08-Sep-2014
 * C source code generated on : Sat Mar 07 15:57:43 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ext_types.h"

/* data type size table */
static uint_T rtDataTypeSizes[] = {
  sizeof(real_T),
  sizeof(real32_T),
  sizeof(int8_T),
  sizeof(uint8_T),
  sizeof(int16_T),
  sizeof(uint16_T),
  sizeof(int32_T),
  sizeof(uint32_T),
  sizeof(boolean_T),
  sizeof(fcn_call_T),
  sizeof(int_T),
  sizeof(pointer_T),
  sizeof(action_T),
  2*sizeof(uint32_T),
  sizeof(int16_T),
  sizeof(int32_T)
};

/* data type name table */
static const char_T * rtDataTypeNames[] = {
  "real_T",
  "real32_T",
  "int8_T",
  "uint8_T",
  "int16_T",
  "uint16_T",
  "int32_T",
  "uint32_T",
  "boolean_T",
  "fcn_call_T",
  "int_T",
  "pointer_T",
  "action_T",
  "timer_uint32_pair_T",
  "int16_T",
  "int32_T"
};

/* data type transitions for block I/O structure */
static DataTypeTransition rtBTransitions[] = {
  { (char_T *)(&MinSeg_Controller_B.Switch), 0, 0, 13 },

  { (char_T *)(&MinSeg_Controller_B.GyroDriverSFunction_o1), 4, 0, 4 },

  { (char_T *)(&MinSeg_Controller_B.DataTypeConversion), 3, 0, 2 },

  { (char_T *)(&MinSeg_Controller_B.PushbuttonA3), 8, 0, 4 }
  ,

  { (char_T *)(&MinSeg_Controller_DWork.GyroDriverSFunction_DSTATE), 0, 0, 110 },

  { (char_T *)(&MinSeg_Controller_DWork.Scope_PWORK.LoggedData), 11, 0, 3 },

  { (char_T *)(&MinSeg_Controller_DWork.DiscreteFIRFilter_circBuf), 6, 0, 1 },

  { (char_T *)(&MinSeg_Controller_DWork.Delay_DSTATE), 8, 0, 1 },

  { (char_T *)(&MinSeg_Controller_DWork.Clear13_SubsysRanBC), 2, 0, 3 },

  { (char_T *)(&MinSeg_Controller_DWork.Clear13_MODE), 8, 0, 3 }
};

/* data type transition table for block I/O structure */
static DataTypeTransitionTable rtBTransTable = {
  10U,
  rtBTransitions
};

/* data type transitions for Parameters structure */
static DataTypeTransition rtPTransitions[] = {
  { (char_T *)(&MinSeg_Controller_P.ES), 0, 0, 21 },

  { (char_T *)(&MinSeg_Controller_P.DigitalOutput_pinNumber), 7, 0, 2 },

  { (char_T *)(&MinSeg_Controller_P.Constant_Value), 0, 0, 121 },

  { (char_T *)(&MinSeg_Controller_P.GainAdjust1_p1), 7, 0, 1 },

  { (char_T *)(&MinSeg_Controller_P.Switch_Threshold), 4, 0, 1 },

  { (char_T *)(&MinSeg_Controller_P.Delay_DelayLength), 5, 0, 1 },

  { (char_T *)(&MinSeg_Controller_P.Gain2_Gain_n), 14, 0, 2 },

  { (char_T *)(&MinSeg_Controller_P.SFunctionBuilder_P1), 3, 0, 5 },

  { (char_T *)(&MinSeg_Controller_P.Delay_InitialCondition), 8, 0, 1 }
};

/* data type transition table for Parameters structure */
static DataTypeTransitionTable rtPTransTable = {
  9U,
  rtPTransitions
};

/* [EOF] MinSeg_Controller_dt.h */
