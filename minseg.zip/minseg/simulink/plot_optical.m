close all
% load and plot similar optical sensor data:
TS=.03
load dat1 
plot( (0:1:length(optsen)-1)*TS,optsen)
hold on
load dat2
plot( (0:1:length(optsen)-1)*TS,optsen, 'r')
legend('custom opt', 'nxt opt')
title('Optical sensor performace with LED ON')
xlabel('time - seconds')
ylabel('ADC value')

% shift data for better comparison
figure
load dat1 
plot((0:1:length(optsen)-1)*TS,optsen)
hold on
load dat2
plot((0:1:length(optsen)-1)*TS,optsen+250, 'r')
legend('custom opt', 'nxt opt')
title('Optical sensor performace with LED ON')
xlabel('time- seconds')
ylabel('ADC value (NXT shifted 250 up)')

