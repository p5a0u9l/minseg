/*
 * File: MinSeg_Controller_v2.c
 *
 * Code generated for Simulink model 'MinSeg_Controller_v2'.
 *
 * Model version                  : 1.467
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * TLC version                    : 8.7 (Aug  5 2014)
 * C/C++ source code generated on : Sun Mar 08 08:19:20 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MinSeg_Controller_v2.h"
#include "MinSeg_Controller_v2_private.h"
#include "MinSeg_Controller_v2_dt.h"

/* Block signals (auto storage) */
BlockIO_MinSeg_Controller_v2 MinSeg_Controller_v2_B;

/* Block states (auto storage) */
D_Work_MinSeg_Controller_v2 MinSeg_Controller_v2_DWork;

/* Real-time model */
RT_MODEL_MinSeg_Controller_v2 MinSeg_Controller_v2_M_;
RT_MODEL_MinSeg_Controller_v2 *const MinSeg_Controller_v2_M =
  &MinSeg_Controller_v2_M_;

/* Model output function */
void MinSeg_Controller_v2_output(void)
{
  /* local block i/o variables */
  real_T rtb_Clock;
  int32_T j;
  int32_T cff;
  uint16_T rtb_GainAdjust1_0;
  real_T rtb_DiscreteFIRFilter;
  real_T rtb_Add2;
  int16_T rtb_Abs;
  uint8_T rtb_DiscreteFIRFilter_0;

  /* Reset subsysRan breadcrumbs */
  srClearBC(MinSeg_Controller_v2_DWork.Clear13_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(MinSeg_Controller_v2_DWork.FSBController_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(MinSeg_Controller_v2_DWork.GyroCalibration_SubsysRanBC);

  /* Clock: '<Root>/Clock' */
  rtb_Clock = MinSeg_Controller_v2_M->Timing.t[0];

  /* Fcn: '<Root>/Fcn' */
  MinSeg_Controller_v2_B.Fcn = ((rtb_Clock > 2.0) && (rtb_Clock < 2.1));

  /* Outputs for Enabled SubSystem: '<Root>/Clear 13 ' incorporates:
   *  EnablePort: '<S1>/Enable'
   */
  if (MinSeg_Controller_v2_B.Fcn > 0.0) {
    /* DataTypeConversion: '<S1>/Data Type Conversion' incorporates:
     *  Constant: '<S1>/Constant'
     */
    MinSeg_Controller_v2_B.DataTypeConversion =
      (MinSeg_Controller_v2_P.Constant_Value != 0.0);

    /* S-Function (sfcn_Digital_Out): '<S1>/S-Function Builder' */
    sfcn_Digital_Out_Outputs_wrapper(&MinSeg_Controller_v2_B.DataTypeConversion,
      &MinSeg_Controller_v2_DWork.SFunctionBuilder_DSTATE,
      &MinSeg_Controller_v2_P.SFunctionBuilder_P1, 1);
    srUpdateBC(MinSeg_Controller_v2_DWork.Clear13_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<Root>/Clear 13 ' */

  /* S-Function (sf_MPU6050_Driver_GxAyz): '<Root>/Gyro Driver SFunction' */
  sf_MPU6050_Driver_GxAyz_Outputs_wrapper
    ( &MinSeg_Controller_v2_B.GyroDriverSFunction_o1,
     &MinSeg_Controller_v2_B.GyroDriverSFunction_o2,
     &MinSeg_Controller_v2_B.GyroDriverSFunction_o3,
     &MinSeg_Controller_v2_DWork.GyroDriverSFunction_DSTATE);

  /* DataTypeConversion: '<Root>/Data Type  Conversion1' */
  MinSeg_Controller_v2_B.DataTypeConversion1 =
    MinSeg_Controller_v2_B.GyroDriverSFunction_o1;

  /* RelationalOperator: '<S2>/Compare' incorporates:
   *  Constant: '<S2>/Constant'
   */
  MinSeg_Controller_v2_B.Compare = (rtb_Clock > MinSeg_Controller_v2_P.tstart);

  /* Logic: '<Root>/Logical Operator' */
  MinSeg_Controller_v2_B.LogicalOperator = !MinSeg_Controller_v2_B.Compare;

  /* Outputs for Enabled SubSystem: '<Root>/Gyro Calibration' incorporates:
   *  EnablePort: '<S4>/Enable'
   */
  if (MinSeg_Controller_v2_B.LogicalOperator) {
    /* DiscreteFir: '<S4>/Discrete FIR Filter' */
    rtb_DiscreteFIRFilter = MinSeg_Controller_v2_B.DataTypeConversion1 *
      MinSeg_Controller_v2_P.DiscreteFIRFilter_Coefficients[0];
    cff = 1L;
    for (j = MinSeg_Controller_v2_DWork.DiscreteFIRFilter_circBuf; j < 99L; j++)
    {
      rtb_DiscreteFIRFilter +=
        MinSeg_Controller_v2_DWork.DiscreteFIRFilter_states[j] *
        MinSeg_Controller_v2_P.DiscreteFIRFilter_Coefficients[cff];
      cff++;
    }

    for (j = 0L; j < MinSeg_Controller_v2_DWork.DiscreteFIRFilter_circBuf; j++)
    {
      rtb_DiscreteFIRFilter +=
        MinSeg_Controller_v2_DWork.DiscreteFIRFilter_states[j] *
        MinSeg_Controller_v2_P.DiscreteFIRFilter_Coefficients[cff];
      cff++;
    }

    /* End of DiscreteFir: '<S4>/Discrete FIR Filter' */

    /* Gain: '<S4>/Gain2' */
    MinSeg_Controller_v2_B.Gain2 = MinSeg_Controller_v2_P.Gain2_Gain *
      rtb_DiscreteFIRFilter;
    srUpdateBC(MinSeg_Controller_v2_DWork.GyroCalibration_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<Root>/Gyro Calibration' */

  /* Outputs for Enabled SubSystem: '<Root>/FSB Controller' incorporates:
   *  EnablePort: '<S3>/Enable'
   */
  if (MinSeg_Controller_v2_B.Compare) {
    /* Gain: '<S3>/convert to  radians1' incorporates:
     *  Constant: '<S6>/Y Bias'
     *  Constant: '<S6>/Z Bias'
     *  DiscreteIntegrator: '<S3>/Discrete-Time  Integrator'
     *  Gain: '<S3>/convert to  radians2'
     *  Gain: '<S3>/convert to  radians3'
     *  Gain: '<S6>/Gain1'
     *  Gain: '<S6>/Gain2'
     *  Product: '<S6>/Divide'
     *  Sum: '<S3>/Sum1'
     *  Sum: '<S6>/Sum'
     *  Sum: '<S6>/Sum1'
     *  Trigonometry: '<S6>/Trigonometric Function'
     */
    rtb_DiscreteFIRFilter = (atan(((real_T)((int32_T)
      MinSeg_Controller_v2_P.Gain2_Gain_m *
      MinSeg_Controller_v2_B.GyroDriverSFunction_o3) * 3.0517578125E-5 -
      MinSeg_Controller_v2_P.ZBias_Value) / ((real_T)((int32_T)
      MinSeg_Controller_v2_P.Gain1_Gain_h *
      MinSeg_Controller_v2_B.GyroDriverSFunction_o2) * 3.0517578125E-5 -
      MinSeg_Controller_v2_P.YBias_Value)) *
      MinSeg_Controller_v2_P.converttoradians3_Gain +
      MinSeg_Controller_v2_P.converttoradians2_Gain *
      MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator_DSTATE) *
      MinSeg_Controller_v2_P.converttoradians1_Gain;

    /* S-Function (sf_Encoder): '<S3>/Encoder SFunction' */
    sf_Encoder_Outputs_wrapper( &MinSeg_Controller_v2_B.EncoderSFunction,
      &MinSeg_Controller_v2_DWork.EncoderSFunction_DSTATE,
      &MinSeg_Controller_v2_P.EncoderSFunction_P1, 1,
      &MinSeg_Controller_v2_P.EncoderSFunction_P2, 1,
      &MinSeg_Controller_v2_P.EncoderSFunction_P3, 1);

    /* Gain: '<S3>/convert to  radians' incorporates:
     *  DataTypeConversion: '<S3>/Data Type  Conversion2'
     */
    rtb_Add2 = MinSeg_Controller_v2_P.ES * (real_T)
      MinSeg_Controller_v2_B.EncoderSFunction;

    /* Gain: '<S3>/conver to radians//sed' incorporates:
     *  Sum: '<S3>/Sum'
     */
    MinSeg_Controller_v2_B.alphadot =
      (MinSeg_Controller_v2_B.DataTypeConversion1 - MinSeg_Controller_v2_B.Gain2)
      * -MinSeg_Controller_v2_P.GS;

    /* SampleTimeMath: '<S5>/TSamp'
     *
     * About '<S5>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    MinSeg_Controller_v2_B.TSamp = rtb_Add2 * MinSeg_Controller_v2_P.TSamp_WtEt;

    /* SignalConversion: '<S3>/TmpSignal ConversionAtLQRInport1' incorporates:
     *  Constant: '<S3>/Constant5'
     *  Sum: '<S3>/Sum3'
     *  Sum: '<S3>/Sum4'
     *  Sum: '<S5>/Diff'
     *  UnitDelay: '<S5>/UD'
     */
    MinSeg_Controller_v2_B.TmpSignalConversionAtLQRInport1[0] =
      (MinSeg_Controller_v2_P.Constant5_Value + rtb_DiscreteFIRFilter) +
      rtb_Add2;
    MinSeg_Controller_v2_B.TmpSignalConversionAtLQRInport1[1] =
      (MinSeg_Controller_v2_B.TSamp - MinSeg_Controller_v2_DWork.UD_DSTATE) +
      MinSeg_Controller_v2_B.alphadot;
    MinSeg_Controller_v2_B.TmpSignalConversionAtLQRInport1[2] =
      rtb_DiscreteFIRFilter;
    MinSeg_Controller_v2_B.TmpSignalConversionAtLQRInport1[3] =
      MinSeg_Controller_v2_B.alphadot;

    /* ManualSwitch: '<S3>/Manual Switch' incorporates:
     *  Constant: '<S3>/Constant1'
     *  DataTypeConversion: '<S3>/Data Type  Conversion3'
     *  Fcn: '<S3>/Fcn1'
     *  S-Function (arduinoanaloginput_sfcn): '<S3>/Gain Adjust1'
     */
    if (MinSeg_Controller_v2_P.ManualSwitch_CurrentSetting == 1) {
      /* S-Function (arduinoanaloginput_sfcn): '<S3>/Gain Adjust1' */
      rtb_GainAdjust1_0 = MW_analogRead(MinSeg_Controller_v2_P.GainAdjust1_p1);
      rtb_Add2 = 0.0014662756598240469 * (real_T)rtb_GainAdjust1_0 + 0.25;
    } else {
      rtb_Add2 = MinSeg_Controller_v2_P.Constant1_Value;
    }

    /* End of ManualSwitch: '<S3>/Manual Switch' */

    /* Gain: '<S7>/conversion to duty cycle (convert to int)' incorporates:
     *  DiscreteIntegrator: '<S3>/Discrete-Time  Integrator'
     *  DiscreteIntegrator: '<S3>/Discrete-Time  Integrator1'
     *  Fcn: '<S3>/Fcn'
     *  Gain: '<S3>/LQR'
     *  Gain: '<S3>/LQR1'
     *  Product: '<S3>/Product'
     *  Product: '<S3>/Product1'
     *  Sum: '<S3>/Sum5'
     */
    rtb_Add2 = floor(((((MinSeg_Controller_v2_P.KLQRC[0] *
                         MinSeg_Controller_v2_B.TmpSignalConversionAtLQRInport1
                         [0] + MinSeg_Controller_v2_P.KLQRC[1] *
                         MinSeg_Controller_v2_B.TmpSignalConversionAtLQRInport1
                         [1]) + MinSeg_Controller_v2_P.KLQRC[2] *
                        MinSeg_Controller_v2_B.TmpSignalConversionAtLQRInport1[2])
                       + MinSeg_Controller_v2_P.KLQRC[3] *
                       MinSeg_Controller_v2_B.TmpSignalConversionAtLQRInport1[3])
                      * rtb_Add2 + (((MinSeg_Controller_v2_P.Ki[0] *
      MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator1_DSTATE[0] +
      MinSeg_Controller_v2_P.Ki[1] *
      MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator1_DSTATE[1]) +
      MinSeg_Controller_v2_P.Ki[2] *
      MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator1_DSTATE[2]) +
      MinSeg_Controller_v2_P.Ki[3] *
      MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator1_DSTATE[3])) * (real_T)
                     (fabs
                      (MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator_DSTATE)
                      < 0.75) * MinSeg_Controller_v2_P.V2DCB);
    if (rtIsNaN(rtb_Add2) || rtIsInf(rtb_Add2)) {
      rtb_Add2 = 0.0;
    } else {
      rtb_Add2 = fmod(rtb_Add2, 65536.0);
    }

    rtb_Abs = rtb_Add2 < 0.0 ? -(int16_T)(uint16_T)-rtb_Add2 : (int16_T)
      (uint16_T)rtb_Add2;

    /* End of Gain: '<S7>/conversion to duty cycle (convert to int)' */

    /* Switch: '<S7>/Switch' incorporates:
     *  Constant: '<S7>/Constant1'
     *  Constant: '<S7>/Constant2'
     */
    if (rtb_Abs >= MinSeg_Controller_v2_P.Switch_Threshold) {
      rtb_DiscreteFIRFilter = MinSeg_Controller_v2_P.Constant2_Value;
    } else {
      rtb_DiscreteFIRFilter = MinSeg_Controller_v2_P.Constant1_Value_n;
    }

    /* End of Switch: '<S7>/Switch' */

    /* DataTypeConversion: '<S8>/Data Type Conversion' */
    if (rtb_DiscreteFIRFilter < 256.0) {
      if (rtb_DiscreteFIRFilter >= 0.0) {
        rtb_DiscreteFIRFilter_0 = (uint8_T)rtb_DiscreteFIRFilter;
      } else {
        rtb_DiscreteFIRFilter_0 = 0U;
      }
    } else {
      rtb_DiscreteFIRFilter_0 = MAX_uint8_T;
    }

    /* End of DataTypeConversion: '<S8>/Data Type Conversion' */

    /* S-Function (arduinodigitaloutput_sfcn): '<S8>/Digital Output' */
    MW_digitalWrite(MinSeg_Controller_v2_P.DigitalOutput_pinNumber,
                    rtb_DiscreteFIRFilter_0);

    /* Abs: '<S7>/Abs' */
    if (rtb_Abs < 0) {
      rtb_Abs = -rtb_Abs;
    }

    /* End of Abs: '<S7>/Abs' */

    /* Sum: '<S7>/Add2' incorporates:
     *  Constant: '<S7>/Constant3'
     */
    rtb_Add2 = MinSeg_Controller_v2_P.Constant3_Value + (real_T)rtb_Abs;

    /* Saturate: '<S7>/Saturation 0 to 255' */
    if (rtb_Add2 > MinSeg_Controller_v2_P.Saturation0to255_UpperSat) {
      rtb_Add2 = MinSeg_Controller_v2_P.Saturation0to255_UpperSat;
    } else {
      if (rtb_Add2 < MinSeg_Controller_v2_P.Saturation0to255_LowerSat) {
        rtb_Add2 = MinSeg_Controller_v2_P.Saturation0to255_LowerSat;
      }
    }

    /* DataTypeConversion: '<S9>/Data Type Conversion' incorporates:
     *  Abs: '<S7>/Abs3'
     *  Gain: '<S7>/Gain1'
     *  Saturate: '<S7>/Saturation 0 to 255'
     *  Sum: '<S7>/Add1'
     */
    rtb_Add2 = fabs(MinSeg_Controller_v2_P.Gain1_Gain * rtb_DiscreteFIRFilter -
                    rtb_Add2);
    if (rtb_Add2 < 256.0) {
      rtb_DiscreteFIRFilter_0 = (uint8_T)rtb_Add2;
    } else {
      rtb_DiscreteFIRFilter_0 = MAX_uint8_T;
    }

    /* End of DataTypeConversion: '<S9>/Data Type Conversion' */

    /* S-Function (arduinoanalogoutput_sfcn): '<S9>/PWM' */
    MW_analogWrite(MinSeg_Controller_v2_P.PWM_pinNumber, rtb_DiscreteFIRFilter_0);
    srUpdateBC(MinSeg_Controller_v2_DWork.FSBController_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<Root>/FSB Controller' */
}

/* Model update function */
void MinSeg_Controller_v2_update(void)
{
  /* Update for Enabled SubSystem: '<Root>/Clear 13 ' incorporates:
   *  Update for EnablePort: '<S1>/Enable'
   */
  if (MinSeg_Controller_v2_B.Fcn > 0.0) {
    /* S-Function "sfcn_Digital_Out_wrapper" Block: <S1>/S-Function Builder */
    sfcn_Digital_Out_Update_wrapper(&MinSeg_Controller_v2_B.DataTypeConversion,
      &MinSeg_Controller_v2_DWork.SFunctionBuilder_DSTATE,
      &MinSeg_Controller_v2_P.SFunctionBuilder_P1, 1);
  }

  /* End of Update for SubSystem: '<Root>/Clear 13 ' */

  /* S-Function "sf_MPU6050_Driver_GxAyz_wrapper" Block: <Root>/Gyro Driver SFunction */
  sf_MPU6050_Driver_GxAyz_Update_wrapper
    ( &MinSeg_Controller_v2_B.GyroDriverSFunction_o1,
     &MinSeg_Controller_v2_B.GyroDriverSFunction_o2,
     &MinSeg_Controller_v2_B.GyroDriverSFunction_o3,
     &MinSeg_Controller_v2_DWork.GyroDriverSFunction_DSTATE);

  /* Update for Enabled SubSystem: '<Root>/Gyro Calibration' incorporates:
   *  Update for EnablePort: '<S4>/Enable'
   */
  if (MinSeg_Controller_v2_B.LogicalOperator) {
    /* Update for DiscreteFir: '<S4>/Discrete FIR Filter' */
    /* Update circular buffer index */
    MinSeg_Controller_v2_DWork.DiscreteFIRFilter_circBuf--;
    if (MinSeg_Controller_v2_DWork.DiscreteFIRFilter_circBuf < 0L) {
      MinSeg_Controller_v2_DWork.DiscreteFIRFilter_circBuf = 98L;
    }

    /* Update circular buffer */
    MinSeg_Controller_v2_DWork.DiscreteFIRFilter_states[MinSeg_Controller_v2_DWork.DiscreteFIRFilter_circBuf]
      = MinSeg_Controller_v2_B.DataTypeConversion1;

    /* End of Update for DiscreteFir: '<S4>/Discrete FIR Filter' */
  }

  /* End of Update for SubSystem: '<Root>/Gyro Calibration' */

  /* Update for Enabled SubSystem: '<Root>/FSB Controller' incorporates:
   *  Update for EnablePort: '<S3>/Enable'
   */
  if (MinSeg_Controller_v2_B.Compare) {
    /* Update for DiscreteIntegrator: '<S3>/Discrete-Time  Integrator' */
    MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator_DSTATE +=
      MinSeg_Controller_v2_P.DiscreteTimeIntegrator_gainval *
      MinSeg_Controller_v2_B.alphadot;

    /* S-Function "sf_Encoder_wrapper" Block: <S3>/Encoder SFunction */
    sf_Encoder_Update_wrapper( &MinSeg_Controller_v2_B.EncoderSFunction,
      &MinSeg_Controller_v2_DWork.EncoderSFunction_DSTATE,
      &MinSeg_Controller_v2_P.EncoderSFunction_P1, 1,
      &MinSeg_Controller_v2_P.EncoderSFunction_P2, 1,
      &MinSeg_Controller_v2_P.EncoderSFunction_P3, 1);

    /* Update for UnitDelay: '<S5>/UD' */
    MinSeg_Controller_v2_DWork.UD_DSTATE = MinSeg_Controller_v2_B.TSamp;

    /* Update for DiscreteIntegrator: '<S3>/Discrete-Time  Integrator1' */
    MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator1_DSTATE[0] +=
      MinSeg_Controller_v2_P.DiscreteTimeIntegrator1_gainval *
      MinSeg_Controller_v2_B.TmpSignalConversionAtLQRInport1[0];
    MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator1_DSTATE[1] +=
      MinSeg_Controller_v2_P.DiscreteTimeIntegrator1_gainval *
      MinSeg_Controller_v2_B.TmpSignalConversionAtLQRInport1[1];
    MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator1_DSTATE[2] +=
      MinSeg_Controller_v2_P.DiscreteTimeIntegrator1_gainval *
      MinSeg_Controller_v2_B.TmpSignalConversionAtLQRInport1[2];
    MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator1_DSTATE[3] +=
      MinSeg_Controller_v2_P.DiscreteTimeIntegrator1_gainval *
      MinSeg_Controller_v2_B.TmpSignalConversionAtLQRInport1[3];
  }

  /* End of Update for SubSystem: '<Root>/FSB Controller' */

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(MinSeg_Controller_v2_M)!=-1) &&
        !((rtmGetTFinal(MinSeg_Controller_v2_M)-MinSeg_Controller_v2_M->
           Timing.t[0]) > MinSeg_Controller_v2_M->Timing.t[0] * (DBL_EPSILON)))
    {
      rtmSetErrorStatus(MinSeg_Controller_v2_M, "Simulation finished");
    }

    if (rtmGetStopRequested(MinSeg_Controller_v2_M)) {
      rtmSetErrorStatus(MinSeg_Controller_v2_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  MinSeg_Controller_v2_M->Timing.t[0] =
    (++MinSeg_Controller_v2_M->Timing.clockTick0) *
    MinSeg_Controller_v2_M->Timing.stepSize0;

  {
    /* Update absolute timer for sample time: [0.03s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.03, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    MinSeg_Controller_v2_M->Timing.clockTick1++;
  }
}

/* Model initialize function */
void MinSeg_Controller_v2_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)MinSeg_Controller_v2_M, 0,
                sizeof(RT_MODEL_MinSeg_Controller_v2));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&MinSeg_Controller_v2_M->solverInfo,
                          &MinSeg_Controller_v2_M->Timing.simTimeStep);
    rtsiSetTPtr(&MinSeg_Controller_v2_M->solverInfo, &rtmGetTPtr
                (MinSeg_Controller_v2_M));
    rtsiSetStepSizePtr(&MinSeg_Controller_v2_M->solverInfo,
                       &MinSeg_Controller_v2_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&MinSeg_Controller_v2_M->solverInfo,
                          (&rtmGetErrorStatus(MinSeg_Controller_v2_M)));
    rtsiSetRTModelPtr(&MinSeg_Controller_v2_M->solverInfo,
                      MinSeg_Controller_v2_M);
  }

  rtsiSetSimTimeStep(&MinSeg_Controller_v2_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&MinSeg_Controller_v2_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(MinSeg_Controller_v2_M, &MinSeg_Controller_v2_M->Timing.tArray[0]);
  rtmSetTFinal(MinSeg_Controller_v2_M, -1);
  MinSeg_Controller_v2_M->Timing.stepSize0 = 0.03;

  /* External mode info */
  MinSeg_Controller_v2_M->Sizes.checksums[0] = (2065064648U);
  MinSeg_Controller_v2_M->Sizes.checksums[1] = (1047479412U);
  MinSeg_Controller_v2_M->Sizes.checksums[2] = (2363425911U);
  MinSeg_Controller_v2_M->Sizes.checksums[3] = (374386595U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[8];
    MinSeg_Controller_v2_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = (sysRanDType *)
      &MinSeg_Controller_v2_DWork.Clear13_SubsysRanBC;
    systemRan[2] = (sysRanDType *)
      &MinSeg_Controller_v2_DWork.FSBController_SubsysRanBC;
    systemRan[3] = (sysRanDType *)
      &MinSeg_Controller_v2_DWork.FSBController_SubsysRanBC;
    systemRan[4] = (sysRanDType *)
      &MinSeg_Controller_v2_DWork.FSBController_SubsysRanBC;
    systemRan[5] = (sysRanDType *)
      &MinSeg_Controller_v2_DWork.FSBController_SubsysRanBC;
    systemRan[6] = (sysRanDType *)
      &MinSeg_Controller_v2_DWork.FSBController_SubsysRanBC;
    systemRan[7] = (sysRanDType *)
      &MinSeg_Controller_v2_DWork.GyroCalibration_SubsysRanBC;
    rteiSetModelMappingInfoPtr(MinSeg_Controller_v2_M->extModeInfo,
      &MinSeg_Controller_v2_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(MinSeg_Controller_v2_M->extModeInfo,
                        MinSeg_Controller_v2_M->Sizes.checksums);
    rteiSetTPtr(MinSeg_Controller_v2_M->extModeInfo, rtmGetTPtr
                (MinSeg_Controller_v2_M));
  }

  /* block I/O */
  (void) memset(((void *) &MinSeg_Controller_v2_B), 0,
                sizeof(BlockIO_MinSeg_Controller_v2));

  /* states (dwork) */
  (void) memset((void *)&MinSeg_Controller_v2_DWork, 0,
                sizeof(D_Work_MinSeg_Controller_v2));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    MinSeg_Controller_v2_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 16;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.B = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.P = &rtPTransTable;
  }

  {
    int16_T i;

    /* InitializeConditions for Enabled SubSystem: '<Root>/Clear 13 ' */

    /* S-Function Block: <S1>/S-Function Builder */
    {
      real_T initVector[1] = { 0 };

      {
        int_T i1;
        for (i1=0; i1 < 1; i1++) {
          MinSeg_Controller_v2_DWork.SFunctionBuilder_DSTATE = initVector[0];
        }
      }
    }

    /* End of InitializeConditions for SubSystem: '<Root>/Clear 13 ' */

    /* InitializeConditions for Enabled SubSystem: '<Root>/Gyro Calibration' */
    /* InitializeConditions for DiscreteFir: '<S4>/Discrete FIR Filter' */
    MinSeg_Controller_v2_DWork.DiscreteFIRFilter_circBuf = 0L;
    for (i = 0; i < 99; i++) {
      MinSeg_Controller_v2_DWork.DiscreteFIRFilter_states[i] =
        MinSeg_Controller_v2_P.DiscreteFIRFilter_InitialStates;
    }

    /* End of InitializeConditions for DiscreteFir: '<S4>/Discrete FIR Filter' */
    /* End of InitializeConditions for SubSystem: '<Root>/Gyro Calibration' */

    /* Start for Enabled SubSystem: '<Root>/FSB Controller' */
    /* Start for S-Function (arduinoanaloginput_sfcn): '<S3>/Gain Adjust1' */
    MW_pinModeAnalogInput(MinSeg_Controller_v2_P.GainAdjust1_p1);

    /* Start for S-Function (arduinodigitaloutput_sfcn): '<S8>/Digital Output' */
    MW_pinModeOutput(MinSeg_Controller_v2_P.DigitalOutput_pinNumber);

    /* Start for S-Function (arduinoanalogoutput_sfcn): '<S9>/PWM' */
    MW_pinModeOutput(MinSeg_Controller_v2_P.PWM_pinNumber);

    /* InitializeConditions for Enabled SubSystem: '<Root>/FSB Controller' */
    /* InitializeConditions for DiscreteIntegrator: '<S3>/Discrete-Time  Integrator' */
    MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator_DSTATE =
      MinSeg_Controller_v2_P.DiscreteTimeIntegrator_IC;

    /* S-Function Block: <S3>/Encoder SFunction */
    {
      real_T initVector[1] = { 0 };

      {
        int_T i1;
        for (i1=0; i1 < 1; i1++) {
          MinSeg_Controller_v2_DWork.EncoderSFunction_DSTATE = initVector[0];
        }
      }
    }

    /* InitializeConditions for UnitDelay: '<S5>/UD' */
    MinSeg_Controller_v2_DWork.UD_DSTATE =
      MinSeg_Controller_v2_P.DiscreteDerivative_ICPrevScaled;

    /* InitializeConditions for DiscreteIntegrator: '<S3>/Discrete-Time  Integrator1' */
    MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator1_DSTATE[0] =
      MinSeg_Controller_v2_P.DiscreteTimeIntegrator1_IC;
    MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator1_DSTATE[1] =
      MinSeg_Controller_v2_P.DiscreteTimeIntegrator1_IC;
    MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator1_DSTATE[2] =
      MinSeg_Controller_v2_P.DiscreteTimeIntegrator1_IC;
    MinSeg_Controller_v2_DWork.DiscreteTimeIntegrator1_DSTATE[3] =
      MinSeg_Controller_v2_P.DiscreteTimeIntegrator1_IC;

    /* End of InitializeConditions for SubSystem: '<Root>/FSB Controller' */

    /* S-Function Block: <Root>/Gyro Driver SFunction */
    {
      real_T initVector[1] = { 0 };

      {
        int_T i1;
        for (i1=0; i1 < 1; i1++) {
          MinSeg_Controller_v2_DWork.GyroDriverSFunction_DSTATE = initVector[0];
        }
      }
    }
  }
}

/* Model terminate function */
void MinSeg_Controller_v2_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
