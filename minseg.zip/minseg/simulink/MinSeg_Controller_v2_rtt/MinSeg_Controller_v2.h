/*
 * File: MinSeg_Controller_v2.h
 *
 * Code generated for Simulink model 'MinSeg_Controller_v2'.
 *
 * Model version                  : 1.467
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * TLC version                    : 8.7 (Aug  5 2014)
 * C/C++ source code generated on : Sun Mar 08 08:19:20 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MinSeg_Controller_v2_h_
#define RTW_HEADER_MinSeg_Controller_v2_h_
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef MinSeg_Controller_v2_COMMON_INCLUDES_
# define MinSeg_Controller_v2_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "dt_info.h"
#include "ext_work.h"
#include "arduino_analoginput_lct.h"
#include "arduino_digitaloutput_lct.h"
#include "arduino_analogoutput_lct.h"
#endif                                 /* MinSeg_Controller_v2_COMMON_INCLUDES_ */

#include "MinSeg_Controller_v2_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

/* Block signals (auto storage) */
typedef struct {
  real_T Fcn;                          /* '<Root>/Fcn' */
  real_T DataTypeConversion1;          /* '<Root>/Data Type  Conversion1' */
  real_T Gain2;                        /* '<S4>/Gain2' */
  real_T alphadot;                     /* '<S3>/conver to radians//sed' */
  real_T TSamp;                        /* '<S5>/TSamp' */
  real_T TmpSignalConversionAtLQRInport1[4];
  int16_T GyroDriverSFunction_o1;      /* '<Root>/Gyro Driver SFunction' */
  int16_T GyroDriverSFunction_o2;      /* '<Root>/Gyro Driver SFunction' */
  int16_T GyroDriverSFunction_o3;      /* '<Root>/Gyro Driver SFunction' */
  int16_T EncoderSFunction;            /* '<S3>/Encoder SFunction' */
  boolean_T Compare;                   /* '<S2>/Compare' */
  boolean_T LogicalOperator;           /* '<Root>/Logical Operator' */
  boolean_T DataTypeConversion;        /* '<S1>/Data Type Conversion' */
} BlockIO_MinSeg_Controller_v2;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T GyroDriverSFunction_DSTATE;   /* '<Root>/Gyro Driver SFunction' */
  real_T DiscreteFIRFilter_states[99]; /* '<S4>/Discrete FIR Filter' */
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S3>/Discrete-Time  Integrator' */
  real_T EncoderSFunction_DSTATE;      /* '<S3>/Encoder SFunction' */
  real_T UD_DSTATE;                    /* '<S5>/UD' */
  real_T DiscreteTimeIntegrator1_DSTATE[4];/* '<S3>/Discrete-Time  Integrator1' */
  real_T SFunctionBuilder_DSTATE;      /* '<S1>/S-Function Builder' */
  struct {
    void *LoggedData;
  } StateSpace_PWORK;                  /* '<S3>/State Space' */

  int32_T DiscreteFIRFilter_circBuf;   /* '<S4>/Discrete FIR Filter' */
  int8_T Clear13_SubsysRanBC;          /* '<Root>/Clear 13 ' */
  int8_T GyroCalibration_SubsysRanBC;  /* '<Root>/Gyro Calibration' */
  int8_T FSBController_SubsysRanBC;    /* '<Root>/FSB Controller' */
} D_Work_MinSeg_Controller_v2;

/* Parameters (auto storage) */
struct Parameters_MinSeg_Controller_v2_ {
  real_T ES;                           /* Variable: ES
                                        * Referenced by: '<S3>/convert to  radians'
                                        */
  real_T GS;                           /* Variable: GS
                                        * Referenced by: '<S3>/conver to radians//sed'
                                        */
  real_T KLQRC[4];                     /* Variable: KLQRC
                                        * Referenced by: '<S3>/LQR'
                                        */
  real_T Ki[4];                        /* Variable: Ki
                                        * Referenced by: '<S3>/LQR1'
                                        */
  real_T V2DCB;                        /* Variable: V2DCB
                                        * Referenced by: '<S7>/conversion to duty cycle (convert to int)'
                                        */
  real_T tstart;                       /* Variable: tstart
                                        * Referenced by: '<S2>/Constant'
                                        */
  real_T DiscreteDerivative_ICPrevScaled;/* Mask Parameter: DiscreteDerivative_ICPrevScaled
                                          * Referenced by: '<S5>/UD'
                                          */
  uint32_T DigitalOutput_pinNumber;    /* Mask Parameter: DigitalOutput_pinNumber
                                        * Referenced by: '<S8>/Digital Output'
                                        */
  uint32_T PWM_pinNumber;              /* Mask Parameter: PWM_pinNumber
                                        * Referenced by: '<S9>/PWM'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S1>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S3>/Constant1'
                                        */
  real_T Constant1_Value_n;            /* Expression: 1
                                        * Referenced by: '<S7>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S7>/Constant2'
                                        */
  real_T DiscreteTimeIntegrator_gainval;/* Computed Parameter: DiscreteTimeIntegrator_gainval
                                         * Referenced by: '<S3>/Discrete-Time  Integrator'
                                         */
  real_T DiscreteTimeIntegrator_IC;    /* Expression: 0
                                        * Referenced by: '<S3>/Discrete-Time  Integrator'
                                        */
  real_T Constant5_Value;              /* Expression: 0
                                        * Referenced by: '<S3>/Constant5'
                                        */
  real_T ZBias_Value;                  /* Expression: 1430
                                        * Referenced by: '<S6>/Z Bias'
                                        */
  real_T YBias_Value;                  /* Expression: 101
                                        * Referenced by: '<S6>/Y Bias'
                                        */
  real_T converttoradians3_Gain;       /* Expression: 0
                                        * Referenced by: '<S3>/convert to  radians3'
                                        */
  real_T converttoradians2_Gain;       /* Expression: 1
                                        * Referenced by: '<S3>/convert to  radians2'
                                        */
  real_T converttoradians1_Gain;       /* Expression: 1
                                        * Referenced by: '<S3>/convert to  radians1'
                                        */
  real_T TSamp_WtEt;                   /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S5>/TSamp'
                                        */
  real_T DiscreteTimeIntegrator1_gainval;/* Computed Parameter: DiscreteTimeIntegrator1_gainval
                                          * Referenced by: '<S3>/Discrete-Time  Integrator1'
                                          */
  real_T DiscreteTimeIntegrator1_IC;   /* Expression: 0
                                        * Referenced by: '<S3>/Discrete-Time  Integrator1'
                                        */
  real_T Constant3_Value;              /* Expression: 10
                                        * Referenced by: '<S7>/Constant3'
                                        */
  real_T Saturation0to255_UpperSat;    /* Expression: 255
                                        * Referenced by: '<S7>/Saturation 0 to 255'
                                        */
  real_T Saturation0to255_LowerSat;    /* Expression: 0
                                        * Referenced by: '<S7>/Saturation 0 to 255'
                                        */
  real_T Gain1_Gain;                   /* Expression: 255
                                        * Referenced by: '<S7>/Gain1'
                                        */
  real_T DiscreteFIRFilter_InitialStates;/* Expression: 0
                                          * Referenced by: '<S4>/Discrete FIR Filter'
                                          */
  real_T DiscreteFIRFilter_Coefficients[100];/* Expression: ones(1,100)
                                              * Referenced by: '<S4>/Discrete FIR Filter'
                                              */
  real_T Gain2_Gain;                   /* Expression: 1/100
                                        * Referenced by: '<S4>/Gain2'
                                        */
  uint32_T GainAdjust1_p1;             /* Computed Parameter: GainAdjust1_p1
                                        * Referenced by: '<S3>/Gain Adjust1'
                                        */
  int16_T Switch_Threshold;            /* Computed Parameter: Switch_Threshold
                                        * Referenced by: '<S7>/Switch'
                                        */
  int16_T Gain2_Gain_m;                /* Computed Parameter: Gain2_Gain_m
                                        * Referenced by: '<S6>/Gain2'
                                        */
  int16_T Gain1_Gain_h;                /* Computed Parameter: Gain1_Gain_h
                                        * Referenced by: '<S6>/Gain1'
                                        */
  uint8_T SFunctionBuilder_P1;         /* Expression: uint8(13)
                                        * Referenced by: '<S1>/S-Function Builder'
                                        */
  uint8_T EncoderSFunction_P1;         /* Expression: uint8(0)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  uint8_T EncoderSFunction_P2;         /* Expression: uint8(18)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  uint8_T EncoderSFunction_P3;         /* Expression: uint8(19)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  uint8_T ManualSwitch_CurrentSetting; /* Computed Parameter: ManualSwitch_CurrentSetting
                                        * Referenced by: '<S3>/Manual Switch'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_MinSeg_Controller_v2 {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (auto storage) */
extern Parameters_MinSeg_Controller_v2 MinSeg_Controller_v2_P;

/* Block signals (auto storage) */
extern BlockIO_MinSeg_Controller_v2 MinSeg_Controller_v2_B;

/* Block states (auto storage) */
extern D_Work_MinSeg_Controller_v2 MinSeg_Controller_v2_DWork;

/* Model entry point functions */
extern void MinSeg_Controller_v2_initialize(void);
extern void MinSeg_Controller_v2_output(void);
extern void MinSeg_Controller_v2_update(void);
extern void MinSeg_Controller_v2_terminate(void);

/* Real-time Model object */
extern RT_MODEL_MinSeg_Controller_v2 *const MinSeg_Controller_v2_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'MinSeg_Controller_v2'
 * '<S1>'   : 'MinSeg_Controller_v2/Clear 13 '
 * '<S2>'   : 'MinSeg_Controller_v2/Compare To Constant'
 * '<S3>'   : 'MinSeg_Controller_v2/FSB Controller'
 * '<S4>'   : 'MinSeg_Controller_v2/Gyro Calibration'
 * '<S5>'   : 'MinSeg_Controller_v2/FSB Controller/Discrete  Derivative'
 * '<S6>'   : 'MinSeg_Controller_v2/FSB Controller/Subsystem'
 * '<S7>'   : 'MinSeg_Controller_v2/FSB Controller/Volts To Adruino PWM 754410 and Motor'
 * '<S8>'   : 'MinSeg_Controller_v2/FSB Controller/Volts To Adruino PWM 754410 and Motor/Digital Output1'
 * '<S9>'   : 'MinSeg_Controller_v2/FSB Controller/Volts To Adruino PWM 754410 and Motor/PWM'
 */
#endif                                 /* RTW_HEADER_MinSeg_Controller_v2_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
