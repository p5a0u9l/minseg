/*
 * File: MinSeg_Controller_v2_types.h
 *
 * Code generated for Simulink model 'MinSeg_Controller_v2'.
 *
 * Model version                  : 1.467
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * TLC version                    : 8.7 (Aug  5 2014)
 * C/C++ source code generated on : Sun Mar 08 08:19:20 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MinSeg_Controller_v2_types_h_
#define RTW_HEADER_MinSeg_Controller_v2_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Parameters (auto storage) */
typedef struct Parameters_MinSeg_Controller_v2_ Parameters_MinSeg_Controller_v2;

/* Forward declaration for rtModel */
typedef struct tag_RTM_MinSeg_Controller_v2 RT_MODEL_MinSeg_Controller_v2;

#endif                                 /* RTW_HEADER_MinSeg_Controller_v2_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
