/*
 * File: timerInterrupt.h
 *
 * Code generated for Simulink model 'MinSeg_Controller_v2'.
 *
 * Model version                  : 1.467
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * TLC version                    : 8.7 (Aug  5 2014)
 * C/C++ source code generated on : Sun Mar 08 08:19:20 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_timerInterrupt_h_
#define RTW_HEADER_timerInterrupt_h_
#include "Arduino.h"
#define disable_Timer_Interrupt        (0)
#define enable_Timer_Interrupt         (0)
#endif                                 /* RTW_HEADER_timerInterrupt_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
