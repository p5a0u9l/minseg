/*
 * File: MinSeg_Controller.h
 *
 * Code generated for Simulink model 'MinSeg_Controller'.
 *
 * Model version                  : 1.34
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * TLC version                    : 8.7 (Aug  5 2014)
 * C/C++ source code generated on : Sat Mar 07 09:12:16 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MinSeg_Controller_h_
#define RTW_HEADER_MinSeg_Controller_h_
#include <math.h>
#include <string.h>
#include <stddef.h>
#ifndef MinSeg_Controller_COMMON_INCLUDES_
# define MinSeg_Controller_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "arduino_analoginput_lct.h"
#include "arduino_digitaloutput_lct.h"
#include "arduino_analogoutput_lct.h"
#endif                                 /* MinSeg_Controller_COMMON_INCLUDES_ */

#include "MinSeg_Controller_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

/* Block signals (auto storage) */
typedef struct {
  real_T Switch;                       /* '<S15>/Switch' */
  real_T DataTypeConversion1;          /* '<Root>/Data Type  Conversion1' */
  real_T Gain2;                        /* '<S4>/Gain2' */
  real_T convertoradianssed;           /* '<S3>/conver to radians//sed' */
  real_T TSamp;                        /* '<S7>/TSamp' */
  real_T TmpSignalConversionAtLQRInport1[4];
  int16_T GyroDriverSFunction_o1;      /* '<Root>/Gyro Driver SFunction' */
  int16_T GyroDriverSFunction_o2;      /* '<Root>/Gyro Driver SFunction' */
  int16_T GyroDriverSFunction_o3;      /* '<Root>/Gyro Driver SFunction' */
  int16_T EncoderSFunction;            /* '<S3>/Encoder SFunction' */
  boolean_T PushbuttonA3;              /* '<Root>/Pushbutton A3' */
  boolean_T DataTypeConversion;        /* '<S1>/Data Type Conversion' */
} BlockIO_MinSeg_Controller;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T PushbuttonA3_DSTATE;          /* '<Root>/Pushbutton A3' */
  real_T GyroDriverSFunction_DSTATE;   /* '<Root>/Gyro Driver SFunction' */
  real_T DiscreteFIRFilter_states[99]; /* '<S4>/Discrete FIR Filter' */
  real_T DiscreteTimeIntegrator1_DSTATE[4];/* '<S10>/Discrete-Time  Integrator1' */
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S3>/Discrete-Time  Integrator' */
  real_T EncoderSFunction_DSTATE;      /* '<S3>/Encoder SFunction' */
  real_T UD_DSTATE;                    /* '<S7>/UD' */
  real_T DiscreteTimeIntegrator1_DSTAT_h[4];/* '<S9>/Discrete-Time  Integrator1' */
  real_T SFunctionBuilder_DSTATE;      /* '<S1>/S-Function Builder' */
  real_T ICic_PreviousInput;           /* '<S15>/IC=ic' */
  int32_T DiscreteFIRFilter_circBuf;   /* '<S4>/Discrete FIR Filter' */
  boolean_T Clear13_MODE;              /* '<Root>/Clear 13 ' */
  boolean_T GyroCalibration_MODE;      /* '<Root>/Gyro Calibration' */
  boolean_T FSBController_MODE;        /* '<Root>/FSB Controller' */
} D_Work_MinSeg_Controller;

/* Parameters (auto storage) */
struct Parameters_MinSeg_Controller_ {
  real_T ES;                           /* Variable: ES
                                        * Referenced by: '<S3>/convert to  radians'
                                        */
  real_T GS;                           /* Variable: GS
                                        * Referenced by: '<S3>/conver to radians//sed'
                                        */
  real_T KLQRC[4];                     /* Variable: KLQRC
                                        * Referenced by:
                                        *   '<S9>/LQR'
                                        *   '<S10>/LQR'
                                        */
  real_T Ki[4];                        /* Variable: Ki
                                        * Referenced by:
                                        *   '<S9>/LQR1'
                                        *   '<S10>/LQR1'
                                        */
  real_T V2DCB;                        /* Variable: V2DCB
                                        * Referenced by: '<S11>/conversion to duty cycle (convert to int)'
                                        */
  real_T tstart;                       /* Variable: tstart
                                        * Referenced by:
                                        *   '<S2>/Constant'
                                        *   '<S5>/Lower Limit'
                                        *   '<S5>/Upper Limit'
                                        */
  real_T DiscreteDerivative_ICPrevScaled;/* Mask Parameter: DiscreteDerivative_ICPrevScaled
                                          * Referenced by: '<S7>/UD'
                                          */
  real_T SampleandHold_ic;             /* Mask Parameter: SampleandHold_ic
                                        * Referenced by: '<S15>/IC=ic'
                                        */
  real_T IntervalTest_lowlimit;        /* Mask Parameter: IntervalTest_lowlimit
                                        * Referenced by: '<S8>/Lower Limit'
                                        */
  real_T IntervalTest_uplimit;         /* Mask Parameter: IntervalTest_uplimit
                                        * Referenced by: '<S8>/Upper Limit'
                                        */
  uint32_T DigitalOutput_pinNumber;    /* Mask Parameter: DigitalOutput_pinNumber
                                        * Referenced by: '<S13>/Digital Output'
                                        */
  uint32_T PWM_pinNumber;              /* Mask Parameter: PWM_pinNumber
                                        * Referenced by: '<S14>/PWM'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S1>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S11>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S11>/Constant2'
                                        */
  real_T DiscreteTimeIntegrator1_gainval;/* Computed Parameter: DiscreteTimeIntegrator1_gainval
                                          * Referenced by: '<S10>/Discrete-Time  Integrator1'
                                          */
  real_T DiscreteTimeIntegrator1_IC;   /* Expression: 0
                                        * Referenced by: '<S10>/Discrete-Time  Integrator1'
                                        */
  real_T Constant5_Value;              /* Expression: 0
                                        * Referenced by: '<S3>/Constant5'
                                        */
  real_T ZBias_Value;                  /* Expression: 1430
                                        * Referenced by: '<S12>/Z Bias'
                                        */
  real_T YBias_Value;                  /* Expression: 101
                                        * Referenced by: '<S12>/Y Bias'
                                        */
  real_T converttoradians3_Gain;       /* Expression: 0
                                        * Referenced by: '<S3>/convert to  radians3'
                                        */
  real_T DiscreteTimeIntegrator_gainval;/* Computed Parameter: DiscreteTimeIntegrator_gainval
                                         * Referenced by: '<S3>/Discrete-Time  Integrator'
                                         */
  real_T DiscreteTimeIntegrator_IC;    /* Expression: 0
                                        * Referenced by: '<S3>/Discrete-Time  Integrator'
                                        */
  real_T converttoradians2_Gain;       /* Expression: 1
                                        * Referenced by: '<S3>/convert to  radians2'
                                        */
  real_T converttoradians1_Gain;       /* Expression: 1
                                        * Referenced by: '<S3>/convert to  radians1'
                                        */
  real_T TSamp_WtEt;                   /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S7>/TSamp'
                                        */
  real_T DiscreteTimeIntegrator1_gainv_d;/* Computed Parameter: DiscreteTimeIntegrator1_gainv_d
                                          * Referenced by: '<S9>/Discrete-Time  Integrator1'
                                          */
  real_T DiscreteTimeIntegrator1_IC_b; /* Expression: 0
                                        * Referenced by: '<S9>/Discrete-Time  Integrator1'
                                        */
  real_T Constant3_Value;              /* Expression: 10
                                        * Referenced by: '<S11>/Constant3'
                                        */
  real_T Saturation0to255_UpperSat;    /* Expression: 255
                                        * Referenced by: '<S11>/Saturation 0 to 255'
                                        */
  real_T Saturation0to255_LowerSat;    /* Expression: 0
                                        * Referenced by: '<S11>/Saturation 0 to 255'
                                        */
  real_T Gain1_Gain;                   /* Expression: 255
                                        * Referenced by: '<S11>/Gain1'
                                        */
  real_T DiscreteFIRFilter_InitialStates;/* Expression: 0
                                          * Referenced by: '<S4>/Discrete FIR Filter'
                                          */
  real_T DiscreteFIRFilter_Coefficients[100];/* Expression: ones(1,100)
                                              * Referenced by: '<S4>/Discrete FIR Filter'
                                              */
  real_T Gain2_Gain;                   /* Expression: 1/100
                                        * Referenced by: '<S4>/Gain2'
                                        */
  uint32_T GainAdjust1_p1;             /* Computed Parameter: GainAdjust1_p1
                                        * Referenced by: '<S9>/Gain Adjust1'
                                        */
  int16_T Switch_Threshold;            /* Computed Parameter: Switch_Threshold
                                        * Referenced by: '<S11>/Switch'
                                        */
  int16_T Gain2_Gain_n;                /* Computed Parameter: Gain2_Gain_n
                                        * Referenced by: '<S12>/Gain2'
                                        */
  int16_T Gain1_Gain_j;                /* Computed Parameter: Gain1_Gain_j
                                        * Referenced by: '<S12>/Gain1'
                                        */
  uint8_T SFunctionBuilder_P1;         /* Expression: uint8(13)
                                        * Referenced by: '<S1>/S-Function Builder'
                                        */
  uint8_T EncoderSFunction_P1;         /* Expression: uint8(0)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  uint8_T EncoderSFunction_P2;         /* Expression: uint8(18)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  uint8_T EncoderSFunction_P3;         /* Expression: uint8(19)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  uint8_T ManualSwitch_CurrentSetting; /* Computed Parameter: ManualSwitch_CurrentSetting
                                        * Referenced by: '<S3>/Manual Switch'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_MinSeg_Controller {
  const char_T * volatile errorStatus;
  RTWSolverInfo solverInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (auto storage) */
extern Parameters_MinSeg_Controller MinSeg_Controller_P;

/* Block signals (auto storage) */
extern BlockIO_MinSeg_Controller MinSeg_Controller_B;

/* Block states (auto storage) */
extern D_Work_MinSeg_Controller MinSeg_Controller_DWork;

/* Model entry point functions */
extern void MinSeg_Controller_initialize(void);
extern void MinSeg_Controller_output(void);
extern void MinSeg_Controller_update(void);
extern void MinSeg_Controller_terminate(void);

/* Real-time Model object */
extern RT_MODEL_MinSeg_Controller *const MinSeg_Controller_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'MinSeg_Controller'
 * '<S1>'   : 'MinSeg_Controller/Clear 13 '
 * '<S2>'   : 'MinSeg_Controller/Compare To Constant'
 * '<S3>'   : 'MinSeg_Controller/FSB Controller'
 * '<S4>'   : 'MinSeg_Controller/Gyro Calibration'
 * '<S5>'   : 'MinSeg_Controller/Interval Test'
 * '<S6>'   : 'MinSeg_Controller/Sample and Hold'
 * '<S7>'   : 'MinSeg_Controller/FSB Controller/Discrete  Derivative'
 * '<S8>'   : 'MinSeg_Controller/FSB Controller/Interval Test'
 * '<S9>'   : 'MinSeg_Controller/FSB Controller/LQR Controller'
 * '<S10>'  : 'MinSeg_Controller/FSB Controller/State Feedback Controller'
 * '<S11>'  : 'MinSeg_Controller/FSB Controller/Volts To Adruino PWM 754410 and Motor'
 * '<S12>'  : 'MinSeg_Controller/FSB Controller/angle_trigonometry'
 * '<S13>'  : 'MinSeg_Controller/FSB Controller/Volts To Adruino PWM 754410 and Motor/Digital Output1'
 * '<S14>'  : 'MinSeg_Controller/FSB Controller/Volts To Adruino PWM 754410 and Motor/PWM'
 * '<S15>'  : 'MinSeg_Controller/Sample and Hold/Model'
 */
#endif                                 /* RTW_HEADER_MinSeg_Controller_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
