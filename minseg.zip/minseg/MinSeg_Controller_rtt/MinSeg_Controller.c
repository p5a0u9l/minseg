/*
 * File: MinSeg_Controller.c
 *
 * Code generated for Simulink model 'MinSeg_Controller'.
 *
 * Model version                  : 1.34
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * TLC version                    : 8.7 (Aug  5 2014)
 * C/C++ source code generated on : Sat Mar 07 09:12:16 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MinSeg_Controller.h"
#include "MinSeg_Controller_private.h"

/* Block signals (auto storage) */
BlockIO_MinSeg_Controller MinSeg_Controller_B;

/* Block states (auto storage) */
D_Work_MinSeg_Controller MinSeg_Controller_DWork;

/* Real-time model */
RT_MODEL_MinSeg_Controller MinSeg_Controller_M_;
RT_MODEL_MinSeg_Controller *const MinSeg_Controller_M = &MinSeg_Controller_M_;

/* Model output function */
void MinSeg_Controller_output(void)
{
  /* local block i/o variables */
  real_T rtb_Add;
  int32_T j;
  int32_T cff;
  uint16_T rtb_GainAdjust1_0;
  real_T rtb_DiscreteFIRFilter;
  real_T rtb_Add2;
  boolean_T Compare;
  int16_T i;
  uint8_T rtb_DiscreteFIRFilter_0;

  /* Clock: '<Root>/Clock1' */
  rtb_Add = MinSeg_Controller_M->Timing.t[0];

  /* S-Function (sfcn_A3_IN): '<Root>/Pushbutton A3' */
  sfcn_A3_IN_Outputs_wrapper( &MinSeg_Controller_B.PushbuttonA3,
    &MinSeg_Controller_DWork.PushbuttonA3_DSTATE);

  /* Switch: '<S15>/Switch' incorporates:
   *  Memory: '<S15>/IC=ic'
   */
  if (MinSeg_Controller_B.PushbuttonA3) {
    MinSeg_Controller_B.Switch = rtb_Add;
  } else {
    MinSeg_Controller_B.Switch = MinSeg_Controller_DWork.ICic_PreviousInput;
  }

  /* End of Switch: '<S15>/Switch' */

  /* Sum: '<Root>/Add' */
  rtb_Add -= MinSeg_Controller_B.Switch;

  /* Outputs for Enabled SubSystem: '<Root>/Clear 13 ' incorporates:
   *  EnablePort: '<S1>/Enable'
   */
  /* Logic: '<S5>/AND' incorporates:
   *  Constant: '<S5>/Lower Limit'
   *  Constant: '<S5>/Upper Limit'
   *  RelationalOperator: '<S5>/Lower Test'
   *  RelationalOperator: '<S5>/Upper Test'
   *  S-Function (sfcn_Digital_Out): '<S1>/S-Function Builder'
   */
  if ((MinSeg_Controller_P.tstart < rtb_Add) && (rtb_Add <
       MinSeg_Controller_P.tstart + 0.1)) {
    if (!MinSeg_Controller_DWork.Clear13_MODE) {
      /* S-Function Block: <S1>/S-Function Builder */
      {
        real_T initVector[1] = { 0 };

        {
          int_T i1;
          for (i1=0; i1 < 1; i1++) {
            MinSeg_Controller_DWork.SFunctionBuilder_DSTATE = initVector[0];
          }
        }
      }

      MinSeg_Controller_DWork.Clear13_MODE = true;
    }

    /* DataTypeConversion: '<S1>/Data Type Conversion' incorporates:
     *  Constant: '<S1>/Constant'
     *  S-Function (sfcn_Digital_Out): '<S1>/S-Function Builder'
     */
    MinSeg_Controller_B.DataTypeConversion = (MinSeg_Controller_P.Constant_Value
      != 0.0);

    /* S-Function (sfcn_Digital_Out): '<S1>/S-Function Builder' */
    sfcn_Digital_Out_Outputs_wrapper(&MinSeg_Controller_B.DataTypeConversion,
      &MinSeg_Controller_DWork.SFunctionBuilder_DSTATE,
      &MinSeg_Controller_P.SFunctionBuilder_P1, 1);
  } else {
    if (MinSeg_Controller_DWork.Clear13_MODE) {
      MinSeg_Controller_DWork.Clear13_MODE = false;
    }
  }

  /* End of Logic: '<S5>/AND' */
  /* End of Outputs for SubSystem: '<Root>/Clear 13 ' */

  /* S-Function (sf_MPU6050_Driver_GxAyz): '<Root>/Gyro Driver SFunction' */
  sf_MPU6050_Driver_GxAyz_Outputs_wrapper
    ( &MinSeg_Controller_B.GyroDriverSFunction_o1,
     &MinSeg_Controller_B.GyroDriverSFunction_o2,
     &MinSeg_Controller_B.GyroDriverSFunction_o3,
     &MinSeg_Controller_DWork.GyroDriverSFunction_DSTATE);

  /* DataTypeConversion: '<Root>/Data Type  Conversion1' */
  MinSeg_Controller_B.DataTypeConversion1 =
    MinSeg_Controller_B.GyroDriverSFunction_o1;

  /* RelationalOperator: '<S2>/Compare' incorporates:
   *  Constant: '<S2>/Constant'
   */
  Compare = (rtb_Add > MinSeg_Controller_P.tstart);

  /* Outputs for Enabled SubSystem: '<Root>/Gyro Calibration' incorporates:
   *  EnablePort: '<S4>/Enable'
   */
  /* Logic: '<Root>/Logical Operator' */
  if (!Compare) {
    if (!MinSeg_Controller_DWork.GyroCalibration_MODE) {
      /* InitializeConditions for DiscreteFir: '<S4>/Discrete FIR Filter' */
      MinSeg_Controller_DWork.DiscreteFIRFilter_circBuf = 0L;
      for (i = 0; i < 99; i++) {
        MinSeg_Controller_DWork.DiscreteFIRFilter_states[i] =
          MinSeg_Controller_P.DiscreteFIRFilter_InitialStates;
      }

      /* End of InitializeConditions for DiscreteFir: '<S4>/Discrete FIR Filter' */
      MinSeg_Controller_DWork.GyroCalibration_MODE = true;
    }

    /* DiscreteFir: '<S4>/Discrete FIR Filter' */
    rtb_DiscreteFIRFilter = MinSeg_Controller_B.DataTypeConversion1 *
      MinSeg_Controller_P.DiscreteFIRFilter_Coefficients[0];
    cff = 1L;
    for (j = MinSeg_Controller_DWork.DiscreteFIRFilter_circBuf; j < 99L; j++) {
      rtb_DiscreteFIRFilter +=
        MinSeg_Controller_DWork.DiscreteFIRFilter_states[j] *
        MinSeg_Controller_P.DiscreteFIRFilter_Coefficients[cff];
      cff++;
    }

    for (j = 0L; j < MinSeg_Controller_DWork.DiscreteFIRFilter_circBuf; j++) {
      rtb_DiscreteFIRFilter +=
        MinSeg_Controller_DWork.DiscreteFIRFilter_states[j] *
        MinSeg_Controller_P.DiscreteFIRFilter_Coefficients[cff];
      cff++;
    }

    /* End of DiscreteFir: '<S4>/Discrete FIR Filter' */

    /* Gain: '<S4>/Gain2' */
    MinSeg_Controller_B.Gain2 = MinSeg_Controller_P.Gain2_Gain *
      rtb_DiscreteFIRFilter;
  } else {
    if (MinSeg_Controller_DWork.GyroCalibration_MODE) {
      MinSeg_Controller_DWork.GyroCalibration_MODE = false;
    }
  }

  /* End of Logic: '<Root>/Logical Operator' */
  /* End of Outputs for SubSystem: '<Root>/Gyro Calibration' */

  /* Outputs for Enabled SubSystem: '<Root>/FSB Controller' incorporates:
   *  EnablePort: '<S3>/Enable'
   */
  if (Compare) {
    if (!MinSeg_Controller_DWork.FSBController_MODE) {
      /* InitializeConditions for DiscreteIntegrator: '<S10>/Discrete-Time  Integrator1' */
      MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[0] =
        MinSeg_Controller_P.DiscreteTimeIntegrator1_IC;
      MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[1] =
        MinSeg_Controller_P.DiscreteTimeIntegrator1_IC;
      MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[2] =
        MinSeg_Controller_P.DiscreteTimeIntegrator1_IC;
      MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[3] =
        MinSeg_Controller_P.DiscreteTimeIntegrator1_IC;

      /* InitializeConditions for DiscreteIntegrator: '<S3>/Discrete-Time  Integrator' */
      MinSeg_Controller_DWork.DiscreteTimeIntegrator_DSTATE =
        MinSeg_Controller_P.DiscreteTimeIntegrator_IC;

      /* S-Function Block: <S3>/Encoder SFunction */
      {
        real_T initVector[1] = { 0 };

        {
          int_T i1;
          for (i1=0; i1 < 1; i1++) {
            MinSeg_Controller_DWork.EncoderSFunction_DSTATE = initVector[0];
          }
        }
      }

      /* InitializeConditions for UnitDelay: '<S7>/UD' */
      MinSeg_Controller_DWork.UD_DSTATE =
        MinSeg_Controller_P.DiscreteDerivative_ICPrevScaled;

      /* InitializeConditions for DiscreteIntegrator: '<S9>/Discrete-Time  Integrator1' */
      MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[0] =
        MinSeg_Controller_P.DiscreteTimeIntegrator1_IC_b;
      MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[1] =
        MinSeg_Controller_P.DiscreteTimeIntegrator1_IC_b;
      MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[2] =
        MinSeg_Controller_P.DiscreteTimeIntegrator1_IC_b;
      MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[3] =
        MinSeg_Controller_P.DiscreteTimeIntegrator1_IC_b;
      MinSeg_Controller_DWork.FSBController_MODE = true;
    }

    /* Gain: '<S3>/convert to  radians1' incorporates:
     *  Constant: '<S12>/Y Bias'
     *  Constant: '<S12>/Z Bias'
     *  DiscreteIntegrator: '<S3>/Discrete-Time  Integrator'
     *  Gain: '<S12>/Gain1'
     *  Gain: '<S12>/Gain2'
     *  Gain: '<S3>/convert to  radians2'
     *  Gain: '<S3>/convert to  radians3'
     *  Product: '<S12>/Divide'
     *  Sum: '<S12>/Sum'
     *  Sum: '<S12>/Sum1'
     *  Sum: '<S3>/Sum1'
     *  Trigonometry: '<S12>/Trigonometric Function'
     */
    rtb_DiscreteFIRFilter = (atan(((real_T)((int32_T)
      MinSeg_Controller_P.Gain2_Gain_n *
      MinSeg_Controller_B.GyroDriverSFunction_o3) * 3.0517578125E-5 -
      MinSeg_Controller_P.ZBias_Value) / ((real_T)((int32_T)
      MinSeg_Controller_P.Gain1_Gain_j *
      MinSeg_Controller_B.GyroDriverSFunction_o2) * 3.0517578125E-5 -
      MinSeg_Controller_P.YBias_Value)) *
      MinSeg_Controller_P.converttoradians3_Gain +
      MinSeg_Controller_P.converttoradians2_Gain *
      MinSeg_Controller_DWork.DiscreteTimeIntegrator_DSTATE) *
      MinSeg_Controller_P.converttoradians1_Gain;

    /* S-Function (sf_Encoder): '<S3>/Encoder SFunction' */
    sf_Encoder_Outputs_wrapper( &MinSeg_Controller_B.EncoderSFunction,
      &MinSeg_Controller_DWork.EncoderSFunction_DSTATE,
      &MinSeg_Controller_P.EncoderSFunction_P1, 1,
      &MinSeg_Controller_P.EncoderSFunction_P2, 1,
      &MinSeg_Controller_P.EncoderSFunction_P3, 1);

    /* Gain: '<S3>/convert to  radians' incorporates:
     *  DataTypeConversion: '<S3>/Data Type  Conversion2'
     */
    rtb_Add2 = MinSeg_Controller_P.ES * (real_T)
      MinSeg_Controller_B.EncoderSFunction;

    /* Gain: '<S3>/conver to radians//sed' incorporates:
     *  Sum: '<S3>/Sum'
     */
    MinSeg_Controller_B.convertoradianssed =
      (MinSeg_Controller_B.DataTypeConversion1 - MinSeg_Controller_B.Gain2) *
      -MinSeg_Controller_P.GS;

    /* SampleTimeMath: '<S7>/TSamp'
     *
     * About '<S7>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    MinSeg_Controller_B.TSamp = rtb_Add2 * MinSeg_Controller_P.TSamp_WtEt;

    /* SignalConversion: '<S9>/TmpSignal ConversionAtLQRInport1' incorporates:
     *  Constant: '<S3>/Constant5'
     *  Sum: '<S3>/Sum3'
     *  Sum: '<S3>/Sum4'
     *  Sum: '<S7>/Diff'
     *  UnitDelay: '<S7>/UD'
     */
    MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[0] =
      (MinSeg_Controller_P.Constant5_Value + rtb_DiscreteFIRFilter) + rtb_Add2;
    MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[1] =
      (MinSeg_Controller_B.TSamp - MinSeg_Controller_DWork.UD_DSTATE) +
      MinSeg_Controller_B.convertoradianssed;
    MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[2] =
      rtb_DiscreteFIRFilter;
    MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[3] =
      MinSeg_Controller_B.convertoradianssed;

    /* ManualSwitch: '<S3>/Manual Switch' incorporates:
     *  DataTypeConversion: '<S9>/Data Type  Conversion3'
     *  DiscreteIntegrator: '<S10>/Discrete-Time  Integrator1'
     *  DiscreteIntegrator: '<S9>/Discrete-Time  Integrator1'
     *  Fcn: '<S10>/Fcn1'
     *  Fcn: '<S9>/Fcn1'
     *  Gain: '<S10>/LQR'
     *  Gain: '<S10>/LQR1'
     *  Gain: '<S9>/LQR'
     *  Gain: '<S9>/LQR1'
     *  Product: '<S10>/Product'
     *  Product: '<S9>/Product'
     *  S-Function (arduinoanaloginput_sfcn): '<S9>/Gain Adjust1'
     *  Sum: '<S10>/Sum5'
     *  Sum: '<S9>/Sum5'
     */
    if (MinSeg_Controller_P.ManualSwitch_CurrentSetting == 1) {
      rtb_DiscreteFIRFilter = (((MinSeg_Controller_P.KLQRC[0] *
        MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[0] +
        MinSeg_Controller_P.KLQRC[1] *
        MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[1]) +
        MinSeg_Controller_P.KLQRC[2] *
        MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[2]) +
        MinSeg_Controller_P.KLQRC[3] *
        MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[3]) * 0.25 +
        (((MinSeg_Controller_P.Ki[0] *
           MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[0] +
           MinSeg_Controller_P.Ki[1] *
           MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[1]) +
          MinSeg_Controller_P.Ki[2] *
          MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[2]) +
         MinSeg_Controller_P.Ki[3] *
         MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[3]);
    } else {
      /* S-Function (arduinoanaloginput_sfcn): '<S9>/Gain Adjust1' */
      rtb_GainAdjust1_0 = MW_analogRead(MinSeg_Controller_P.GainAdjust1_p1);
      rtb_DiscreteFIRFilter = (((MinSeg_Controller_P.KLQRC[0] *
        MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[0] +
        MinSeg_Controller_P.KLQRC[1] *
        MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[1]) +
        MinSeg_Controller_P.KLQRC[2] *
        MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[2]) +
        MinSeg_Controller_P.KLQRC[3] *
        MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[3]) *
        (0.0014662756598240469 * (real_T)rtb_GainAdjust1_0 + 0.25) +
        (((MinSeg_Controller_P.Ki[0] *
           MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[0] +
           MinSeg_Controller_P.Ki[1] *
           MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[1]) +
          MinSeg_Controller_P.Ki[2] *
          MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[2]) +
         MinSeg_Controller_P.Ki[3] *
         MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[3]);
    }

    /* End of ManualSwitch: '<S3>/Manual Switch' */

    /* Gain: '<S11>/conversion to duty cycle (convert to int)' incorporates:
     *  Constant: '<S8>/Lower Limit'
     *  Constant: '<S8>/Upper Limit'
     *  DiscreteIntegrator: '<S3>/Discrete-Time  Integrator'
     *  Logic: '<S8>/AND'
     *  Product: '<S11>/Product1'
     *  RelationalOperator: '<S8>/Lower Test'
     *  RelationalOperator: '<S8>/Upper Test'
     */
    rtb_Add2 = floor((real_T)((MinSeg_Controller_P.IntervalTest_lowlimit <
      MinSeg_Controller_DWork.DiscreteTimeIntegrator_DSTATE) &&
      (MinSeg_Controller_DWork.DiscreteTimeIntegrator_DSTATE <
       MinSeg_Controller_P.IntervalTest_uplimit)) * rtb_DiscreteFIRFilter *
                     MinSeg_Controller_P.V2DCB);
    if (rtIsNaN(rtb_Add2) || rtIsInf(rtb_Add2)) {
      rtb_Add2 = 0.0;
    } else {
      rtb_Add2 = fmod(rtb_Add2, 65536.0);
    }

    i = rtb_Add2 < 0.0 ? -(int16_T)(uint16_T)-rtb_Add2 : (int16_T)(uint16_T)
      rtb_Add2;

    /* End of Gain: '<S11>/conversion to duty cycle (convert to int)' */

    /* Switch: '<S11>/Switch' incorporates:
     *  Constant: '<S11>/Constant1'
     *  Constant: '<S11>/Constant2'
     */
    if (i >= MinSeg_Controller_P.Switch_Threshold) {
      rtb_DiscreteFIRFilter = MinSeg_Controller_P.Constant2_Value;
    } else {
      rtb_DiscreteFIRFilter = MinSeg_Controller_P.Constant1_Value;
    }

    /* End of Switch: '<S11>/Switch' */

    /* DataTypeConversion: '<S13>/Data Type Conversion' */
    if (rtb_DiscreteFIRFilter < 256.0) {
      if (rtb_DiscreteFIRFilter >= 0.0) {
        rtb_DiscreteFIRFilter_0 = (uint8_T)rtb_DiscreteFIRFilter;
      } else {
        rtb_DiscreteFIRFilter_0 = 0U;
      }
    } else {
      rtb_DiscreteFIRFilter_0 = MAX_uint8_T;
    }

    /* End of DataTypeConversion: '<S13>/Data Type Conversion' */

    /* S-Function (arduinodigitaloutput_sfcn): '<S13>/Digital Output' */
    MW_digitalWrite(MinSeg_Controller_P.DigitalOutput_pinNumber,
                    rtb_DiscreteFIRFilter_0);

    /* Abs: '<S11>/Abs' */
    if (i < 0) {
      i = -i;
    }

    /* End of Abs: '<S11>/Abs' */

    /* Sum: '<S11>/Add2' incorporates:
     *  Constant: '<S11>/Constant3'
     */
    rtb_Add2 = MinSeg_Controller_P.Constant3_Value + (real_T)i;

    /* Saturate: '<S11>/Saturation 0 to 255' */
    if (rtb_Add2 > MinSeg_Controller_P.Saturation0to255_UpperSat) {
      rtb_Add2 = MinSeg_Controller_P.Saturation0to255_UpperSat;
    } else {
      if (rtb_Add2 < MinSeg_Controller_P.Saturation0to255_LowerSat) {
        rtb_Add2 = MinSeg_Controller_P.Saturation0to255_LowerSat;
      }
    }

    /* DataTypeConversion: '<S14>/Data Type Conversion' incorporates:
     *  Abs: '<S11>/Abs3'
     *  Gain: '<S11>/Gain1'
     *  Saturate: '<S11>/Saturation 0 to 255'
     *  Sum: '<S11>/Add1'
     */
    rtb_Add2 = fabs(MinSeg_Controller_P.Gain1_Gain * rtb_DiscreteFIRFilter -
                    rtb_Add2);
    if (rtb_Add2 < 256.0) {
      rtb_DiscreteFIRFilter_0 = (uint8_T)rtb_Add2;
    } else {
      rtb_DiscreteFIRFilter_0 = MAX_uint8_T;
    }

    /* End of DataTypeConversion: '<S14>/Data Type Conversion' */

    /* S-Function (arduinoanalogoutput_sfcn): '<S14>/PWM' */
    MW_analogWrite(MinSeg_Controller_P.PWM_pinNumber, rtb_DiscreteFIRFilter_0);
  } else {
    if (MinSeg_Controller_DWork.FSBController_MODE) {
      MinSeg_Controller_DWork.FSBController_MODE = false;
    }
  }

  /* End of Outputs for SubSystem: '<Root>/FSB Controller' */
}

/* Model update function */
void MinSeg_Controller_update(void)
{
  /* S-Function "sfcn_A3_IN_wrapper" Block: <Root>/Pushbutton A3 */
  sfcn_A3_IN_Update_wrapper( &MinSeg_Controller_B.PushbuttonA3,
    &MinSeg_Controller_DWork.PushbuttonA3_DSTATE);

  /* Update for Memory: '<S15>/IC=ic' */
  MinSeg_Controller_DWork.ICic_PreviousInput = MinSeg_Controller_B.Switch;

  /* Update for Enabled SubSystem: '<Root>/Clear 13 ' incorporates:
   *  Update for EnablePort: '<S1>/Enable'
   */
  if (MinSeg_Controller_DWork.Clear13_MODE) {
    /* S-Function "sfcn_Digital_Out_wrapper" Block: <S1>/S-Function Builder */
    sfcn_Digital_Out_Update_wrapper(&MinSeg_Controller_B.DataTypeConversion,
      &MinSeg_Controller_DWork.SFunctionBuilder_DSTATE,
      &MinSeg_Controller_P.SFunctionBuilder_P1, 1);
  }

  /* End of Update for SubSystem: '<Root>/Clear 13 ' */

  /* S-Function "sf_MPU6050_Driver_GxAyz_wrapper" Block: <Root>/Gyro Driver SFunction */
  sf_MPU6050_Driver_GxAyz_Update_wrapper
    ( &MinSeg_Controller_B.GyroDriverSFunction_o1,
     &MinSeg_Controller_B.GyroDriverSFunction_o2,
     &MinSeg_Controller_B.GyroDriverSFunction_o3,
     &MinSeg_Controller_DWork.GyroDriverSFunction_DSTATE);

  /* Update for Enabled SubSystem: '<Root>/Gyro Calibration' incorporates:
   *  Update for EnablePort: '<S4>/Enable'
   */
  if (MinSeg_Controller_DWork.GyroCalibration_MODE) {
    /* Update for DiscreteFir: '<S4>/Discrete FIR Filter' */
    /* Update circular buffer index */
    MinSeg_Controller_DWork.DiscreteFIRFilter_circBuf--;
    if (MinSeg_Controller_DWork.DiscreteFIRFilter_circBuf < 0L) {
      MinSeg_Controller_DWork.DiscreteFIRFilter_circBuf = 98L;
    }

    /* Update circular buffer */
    MinSeg_Controller_DWork.DiscreteFIRFilter_states[MinSeg_Controller_DWork.DiscreteFIRFilter_circBuf]
      = MinSeg_Controller_B.DataTypeConversion1;

    /* End of Update for DiscreteFir: '<S4>/Discrete FIR Filter' */
  }

  /* End of Update for SubSystem: '<Root>/Gyro Calibration' */

  /* Update for Enabled SubSystem: '<Root>/FSB Controller' incorporates:
   *  Update for EnablePort: '<S3>/Enable'
   */
  if (MinSeg_Controller_DWork.FSBController_MODE) {
    /* Update for DiscreteIntegrator: '<S10>/Discrete-Time  Integrator1' */
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[0] +=
      MinSeg_Controller_P.DiscreteTimeIntegrator1_gainval *
      MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[0];
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[1] +=
      MinSeg_Controller_P.DiscreteTimeIntegrator1_gainval *
      MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[1];
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[2] +=
      MinSeg_Controller_P.DiscreteTimeIntegrator1_gainval *
      MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[2];
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[3] +=
      MinSeg_Controller_P.DiscreteTimeIntegrator1_gainval *
      MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[3];

    /* Update for DiscreteIntegrator: '<S3>/Discrete-Time  Integrator' */
    MinSeg_Controller_DWork.DiscreteTimeIntegrator_DSTATE +=
      MinSeg_Controller_P.DiscreteTimeIntegrator_gainval *
      MinSeg_Controller_B.convertoradianssed;

    /* S-Function "sf_Encoder_wrapper" Block: <S3>/Encoder SFunction */
    sf_Encoder_Update_wrapper( &MinSeg_Controller_B.EncoderSFunction,
      &MinSeg_Controller_DWork.EncoderSFunction_DSTATE,
      &MinSeg_Controller_P.EncoderSFunction_P1, 1,
      &MinSeg_Controller_P.EncoderSFunction_P2, 1,
      &MinSeg_Controller_P.EncoderSFunction_P3, 1);

    /* Update for UnitDelay: '<S7>/UD' */
    MinSeg_Controller_DWork.UD_DSTATE = MinSeg_Controller_B.TSamp;

    /* Update for DiscreteIntegrator: '<S9>/Discrete-Time  Integrator1' */
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[0] +=
      MinSeg_Controller_P.DiscreteTimeIntegrator1_gainv_d *
      MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[0];
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[1] +=
      MinSeg_Controller_P.DiscreteTimeIntegrator1_gainv_d *
      MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[1];
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[2] +=
      MinSeg_Controller_P.DiscreteTimeIntegrator1_gainv_d *
      MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[2];
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[3] +=
      MinSeg_Controller_P.DiscreteTimeIntegrator1_gainv_d *
      MinSeg_Controller_B.TmpSignalConversionAtLQRInport1[3];
  }

  /* End of Update for SubSystem: '<Root>/FSB Controller' */

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  MinSeg_Controller_M->Timing.t[0] =
    (++MinSeg_Controller_M->Timing.clockTick0) *
    MinSeg_Controller_M->Timing.stepSize0;

  {
    /* Update absolute timer for sample time: [0.005s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.005, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    MinSeg_Controller_M->Timing.clockTick1++;
  }
}

/* Model initialize function */
void MinSeg_Controller_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)MinSeg_Controller_M, 0,
                sizeof(RT_MODEL_MinSeg_Controller));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&MinSeg_Controller_M->solverInfo,
                          &MinSeg_Controller_M->Timing.simTimeStep);
    rtsiSetTPtr(&MinSeg_Controller_M->solverInfo, &rtmGetTPtr
                (MinSeg_Controller_M));
    rtsiSetStepSizePtr(&MinSeg_Controller_M->solverInfo,
                       &MinSeg_Controller_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&MinSeg_Controller_M->solverInfo, ((const char_T **)
      (&rtmGetErrorStatus(MinSeg_Controller_M))));
    rtsiSetRTModelPtr(&MinSeg_Controller_M->solverInfo, MinSeg_Controller_M);
  }

  rtsiSetSimTimeStep(&MinSeg_Controller_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&MinSeg_Controller_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(MinSeg_Controller_M, &MinSeg_Controller_M->Timing.tArray[0]);
  MinSeg_Controller_M->Timing.stepSize0 = 0.005;

  /* block I/O */
  (void) memset(((void *) &MinSeg_Controller_B), 0,
                sizeof(BlockIO_MinSeg_Controller));

  /* states (dwork) */
  (void) memset((void *)&MinSeg_Controller_DWork, 0,
                sizeof(D_Work_MinSeg_Controller));

  {
    int16_T i;

    /* InitializeConditions for Enabled SubSystem: '<Root>/Clear 13 ' */

    /* S-Function Block: <S1>/S-Function Builder */
    {
      real_T initVector[1] = { 0 };

      {
        int_T i1;
        for (i1=0; i1 < 1; i1++) {
          MinSeg_Controller_DWork.SFunctionBuilder_DSTATE = initVector[0];
        }
      }
    }

    /* End of InitializeConditions for SubSystem: '<Root>/Clear 13 ' */

    /* InitializeConditions for Enabled SubSystem: '<Root>/Gyro Calibration' */
    /* InitializeConditions for DiscreteFir: '<S4>/Discrete FIR Filter' */
    MinSeg_Controller_DWork.DiscreteFIRFilter_circBuf = 0L;
    for (i = 0; i < 99; i++) {
      MinSeg_Controller_DWork.DiscreteFIRFilter_states[i] =
        MinSeg_Controller_P.DiscreteFIRFilter_InitialStates;
    }

    /* End of InitializeConditions for DiscreteFir: '<S4>/Discrete FIR Filter' */
    /* End of InitializeConditions for SubSystem: '<Root>/Gyro Calibration' */

    /* Start for Enabled SubSystem: '<Root>/FSB Controller' */
    /* Start for S-Function (arduinoanaloginput_sfcn): '<S9>/Gain Adjust1' */
    MW_pinModeAnalogInput(MinSeg_Controller_P.GainAdjust1_p1);

    /* Start for S-Function (arduinodigitaloutput_sfcn): '<S13>/Digital Output' */
    MW_pinModeOutput(MinSeg_Controller_P.DigitalOutput_pinNumber);

    /* Start for S-Function (arduinoanalogoutput_sfcn): '<S14>/PWM' */
    MW_pinModeOutput(MinSeg_Controller_P.PWM_pinNumber);

    /* End of Start for SubSystem: '<Root>/FSB Controller' */

    /* InitializeConditions for Enabled SubSystem: '<Root>/FSB Controller' */
    /* InitializeConditions for DiscreteIntegrator: '<S10>/Discrete-Time  Integrator1' */
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[0] =
      MinSeg_Controller_P.DiscreteTimeIntegrator1_IC;
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[1] =
      MinSeg_Controller_P.DiscreteTimeIntegrator1_IC;
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[2] =
      MinSeg_Controller_P.DiscreteTimeIntegrator1_IC;
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTATE[3] =
      MinSeg_Controller_P.DiscreteTimeIntegrator1_IC;

    /* InitializeConditions for DiscreteIntegrator: '<S3>/Discrete-Time  Integrator' */
    MinSeg_Controller_DWork.DiscreteTimeIntegrator_DSTATE =
      MinSeg_Controller_P.DiscreteTimeIntegrator_IC;

    /* S-Function Block: <S3>/Encoder SFunction */
    {
      real_T initVector[1] = { 0 };

      {
        int_T i1;
        for (i1=0; i1 < 1; i1++) {
          MinSeg_Controller_DWork.EncoderSFunction_DSTATE = initVector[0];
        }
      }
    }

    /* InitializeConditions for UnitDelay: '<S7>/UD' */
    MinSeg_Controller_DWork.UD_DSTATE =
      MinSeg_Controller_P.DiscreteDerivative_ICPrevScaled;

    /* InitializeConditions for DiscreteIntegrator: '<S9>/Discrete-Time  Integrator1' */
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[0] =
      MinSeg_Controller_P.DiscreteTimeIntegrator1_IC_b;
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[1] =
      MinSeg_Controller_P.DiscreteTimeIntegrator1_IC_b;
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[2] =
      MinSeg_Controller_P.DiscreteTimeIntegrator1_IC_b;
    MinSeg_Controller_DWork.DiscreteTimeIntegrator1_DSTAT_h[3] =
      MinSeg_Controller_P.DiscreteTimeIntegrator1_IC_b;

    /* End of InitializeConditions for SubSystem: '<Root>/FSB Controller' */

    /* S-Function Block: <Root>/Pushbutton A3 */
    {
      real_T initVector[1] = { 0 };

      {
        int_T i1;
        for (i1=0; i1 < 1; i1++) {
          MinSeg_Controller_DWork.PushbuttonA3_DSTATE = initVector[0];
        }
      }
    }

    /* InitializeConditions for Memory: '<S15>/IC=ic' */
    MinSeg_Controller_DWork.ICic_PreviousInput =
      MinSeg_Controller_P.SampleandHold_ic;

    /* S-Function Block: <Root>/Gyro Driver SFunction */
    {
      real_T initVector[1] = { 0 };

      {
        int_T i1;
        for (i1=0; i1 < 1; i1++) {
          MinSeg_Controller_DWork.GyroDriverSFunction_DSTATE = initVector[0];
        }
      }
    }
  }
}

/* Model terminate function */
void MinSeg_Controller_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
