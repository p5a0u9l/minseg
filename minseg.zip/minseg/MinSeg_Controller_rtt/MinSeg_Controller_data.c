/*
 * File: MinSeg_Controller_data.c
 *
 * Code generated for Simulink model 'MinSeg_Controller'.
 *
 * Model version                  : 1.34
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * TLC version                    : 8.7 (Aug  5 2014)
 * C/C++ source code generated on : Sat Mar 07 09:12:16 2015
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MinSeg_Controller.h"
#include "MinSeg_Controller_private.h"

/* Block parameters (auto storage) */
Parameters_MinSeg_Controller MinSeg_Controller_P = {
  -0.0087266462599716477,              /* Variable: ES
                                        * Referenced by: '<S3>/convert to  radians'
                                        */
  0.00015583296892806512,              /* Variable: GS
                                        * Referenced by: '<S3>/conver to radians//sed'
                                        */

  /*  Variable: KLQRC
   * Referenced by:
   *   '<S9>/LQR'
   *   '<S10>/LQR'
   */
  { 8.6951704910073246, 0.20383816896156123, 14.142135623621925,
    74.442175463125068 },

  /*  Variable: Ki
   * Referenced by:
   *   '<S9>/LQR1'
   *   '<S10>/LQR1'
   */
  { -0.016, -0.0, 1.0, 0.0 },
  42.5,                                /* Variable: V2DCB
                                        * Referenced by: '<S11>/conversion to duty cycle (convert to int)'
                                        */
  2.0,                                 /* Variable: tstart
                                        * Referenced by:
                                        *   '<S2>/Constant'
                                        *   '<S5>/Lower Limit'
                                        *   '<S5>/Upper Limit'
                                        */
  0.0,                                 /* Mask Parameter: DiscreteDerivative_ICPrevScaled
                                        * Referenced by: '<S7>/UD'
                                        */
  0.0,                                 /* Mask Parameter: SampleandHold_ic
                                        * Referenced by: '<S15>/IC=ic'
                                        */
  -0.75,                               /* Mask Parameter: IntervalTest_lowlimit
                                        * Referenced by: '<S8>/Lower Limit'
                                        */
  0.75,                                /* Mask Parameter: IntervalTest_uplimit
                                        * Referenced by: '<S8>/Upper Limit'
                                        */
  6U,                                  /* Mask Parameter: DigitalOutput_pinNumber
                                        * Referenced by: '<S13>/Digital Output'
                                        */
  8U,                                  /* Mask Parameter: PWM_pinNumber
                                        * Referenced by: '<S14>/PWM'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Constant'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S11>/Constant1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S11>/Constant2'
                                        */
  0.005,                               /* Computed Parameter: DiscreteTimeIntegrator1_gainval
                                        * Referenced by: '<S10>/Discrete-Time  Integrator1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S10>/Discrete-Time  Integrator1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S3>/Constant5'
                                        */
  1430.0,                              /* Expression: 1430
                                        * Referenced by: '<S12>/Z Bias'
                                        */
  101.0,                               /* Expression: 101
                                        * Referenced by: '<S12>/Y Bias'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S3>/convert to  radians3'
                                        */
  0.005,                               /* Computed Parameter: DiscreteTimeIntegrator_gainval
                                        * Referenced by: '<S3>/Discrete-Time  Integrator'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S3>/Discrete-Time  Integrator'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S3>/convert to  radians2'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S3>/convert to  radians1'
                                        */
  200.0,                               /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S7>/TSamp'
                                        */
  0.005,                               /* Computed Parameter: DiscreteTimeIntegrator1_gainv_d
                                        * Referenced by: '<S9>/Discrete-Time  Integrator1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S9>/Discrete-Time  Integrator1'
                                        */
  10.0,                                /* Expression: 10
                                        * Referenced by: '<S11>/Constant3'
                                        */
  255.0,                               /* Expression: 255
                                        * Referenced by: '<S11>/Saturation 0 to 255'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S11>/Saturation 0 to 255'
                                        */
  255.0,                               /* Expression: 255
                                        * Referenced by: '<S11>/Gain1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/Discrete FIR Filter'
                                        */

  /*  Expression: ones(1,100)
   * Referenced by: '<S4>/Discrete FIR Filter'
   */
  { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 },
  0.01,                                /* Expression: 1/100
                                        * Referenced by: '<S4>/Gain2'
                                        */
  0U,                                  /* Computed Parameter: GainAdjust1_p1
                                        * Referenced by: '<S9>/Gain Adjust1'
                                        */
  0,                                   /* Computed Parameter: Switch_Threshold
                                        * Referenced by: '<S11>/Switch'
                                        */
  -32768,                              /* Computed Parameter: Gain2_Gain_n
                                        * Referenced by: '<S12>/Gain2'
                                        */
  -32768,                              /* Computed Parameter: Gain1_Gain_j
                                        * Referenced by: '<S12>/Gain1'
                                        */
  13U,                                 /* Expression: uint8(13)
                                        * Referenced by: '<S1>/S-Function Builder'
                                        */
  0U,                                  /* Expression: uint8(0)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  18U,                                 /* Expression: uint8(18)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  19U,                                 /* Expression: uint8(19)
                                        * Referenced by: '<S3>/Encoder SFunction'
                                        */
  0U                                   /* Computed Parameter: ManualSwitch_CurrentSetting
                                        * Referenced by: '<S3>/Manual Switch'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
